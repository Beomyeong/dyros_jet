torso and arm swing optimization

one leg and waist

6 tast space
