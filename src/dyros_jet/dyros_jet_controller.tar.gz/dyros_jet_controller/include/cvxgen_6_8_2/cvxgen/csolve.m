% csolve  Solves a custom quadratic program very rapidly.
%
% [vars, status] = csolve(params, settings)
%
% solves the convex optimization problem
%
%   minimize(td*(quad_form(p1, Q) - 2*p0*p1) + ts*quad_form(p2 - p1, Q) + td*(quad_form(p2, Q) - 2*pf*p2))
%   subject to
%     pk - p1 <= 0.15
%     p2 - pk <= 0.15
%
% with variables
%       p1   1 x 1
%       p2   1 x 1
%
% and parameters
%        Q   1 x 1    PSD
%       p0   1 x 1
%       pf   1 x 1
%       pk   1 x 1
%       td   1 x 1    positive
%       ts   1 x 1    positive
%
% Note:
%   - Check status.converged, which will be 1 if optimization succeeded.
%   - You don't have to specify settings if you don't want to.
%   - To hide output, use settings.verbose = 0.
%   - To change iterations, use settings.max_iters = 20.
%   - You may wish to compare with cvxsolve to check the solver is correct.
%
% Specify params.Q, ..., params.ts, then run
%   [vars, status] = csolve(params, settings)
% Produced by CVXGEN, 2019-06-20 05:57:19 -0400.
% CVXGEN is Copyright (C) 2006-2017 Jacob Mattingley, jem@cvxgen.com.
% The code in this file is Copyright (C) 2006-2017 Jacob Mattingley.
% CVXGEN, or solvers produced by CVXGEN, cannot be used for commercial
% applications without prior written permission from Jacob Mattingley.

% Filename: csolve.m.
% Description: Help file for the Matlab solver interface.
