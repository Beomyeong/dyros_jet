single support zmp optimization
