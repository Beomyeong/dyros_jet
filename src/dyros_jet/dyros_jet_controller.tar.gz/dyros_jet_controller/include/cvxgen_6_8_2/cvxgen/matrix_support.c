/* Produced by CVXGEN, 2019-06-20 05:57:19 -0400.  */
/* CVXGEN is Copyright (C) 2006-2017 Jacob Mattingley, jem@cvxgen.com. */
/* The code in this file is Copyright (C) 2006-2017 Jacob Mattingley. */
/* CVXGEN, or solvers produced by CVXGEN, cannot be used for commercial */
/* applications without prior written permission from Jacob Mattingley. */

/* Filename: matrix_support.c. */
/* Description: Support functions for matrix multiplication and vector filling. */
#include "solver.h"
void multbymA(double *lhs, double *rhs) {
  lhs[0] = -rhs[0]*(-1)-rhs[1]*(1)-rhs[2]*(-1);
}
void multbymAT(double *lhs, double *rhs) {
  lhs[0] = -rhs[0]*(-1);
  lhs[1] = -rhs[0]*(1);
  lhs[2] = -rhs[0]*(-1);
}
void multbymG(double *lhs, double *rhs) {
  lhs[0] = -rhs[0]*(-1);
  lhs[1] = -rhs[1]*(1);
}
void multbymGT(double *lhs, double *rhs) {
  lhs[0] = -rhs[0]*(-1);
  lhs[1] = -rhs[1]*(1);
  lhs[2] = 0;
}
void multbyP(double *lhs, double *rhs) {
  /* TODO use the fact that P is symmetric? */
  /* TODO check doubling / half factor etc. */
  lhs[0] = rhs[0]*(2*params.td[0]*params.Q[0]);
  lhs[1] = rhs[1]*(2*params.td[0]*params.Q[0]);
  lhs[2] = rhs[2]*(2*params.ts[0]*params.Q[0]);
}
void fillq(void) {
  work.q[0] = -2*params.td[0]*params.p0[0];
  work.q[1] = -2*params.td[0]*params.pf[0];
  work.q[2] = 0;
}
void fillh(void) {
  work.h[0] = -(-0.15+params.pk[0]);
  work.h[1] = -(-0.15-params.pk[0]);
}
void fillb(void) {
  work.b[0] = 0;
}
void pre_ops(void) {
}
