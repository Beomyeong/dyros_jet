zmp pattern optimization version 1.01
