% csolve  Solves a custom quadratic program very rapidly.
%
% [vars, status] = csolve(params, settings)
%
% solves the convex optimization problem
%
%   minimize(a*quad_form(pk1 - p0 - d, eye(1)) + 4*b*quad_form(d, eye(1)) + a*quad_form(pf - pk1 - d, eye(1)))
%   subject to
%     0 <= d
%     d <= 0.15
%     pk1 - d >= pk0 + 0.15
%     pk1 + d <= pk2 - 0.15
%
% with variables
%        d   1 x 1
%
% and parameters
%        a   1 x 1    positive
%        b   1 x 1    positive
%       p0   1 x 1
%       pf   1 x 1
%      pk0   1 x 1
%      pk1   1 x 1
%      pk2   1 x 1
%
% Note:
%   - Check status.converged, which will be 1 if optimization succeeded.
%   - You don't have to specify settings if you don't want to.
%   - To hide output, use settings.verbose = 0.
%   - To change iterations, use settings.max_iters = 20.
%   - You may wish to compare with cvxsolve to check the solver is correct.
%
% Specify params.a, ..., params.pk2, then run
%   [vars, status] = csolve(params, settings)
% Produced by CVXGEN, 2019-06-21 04:09:48 -0400.
% CVXGEN is Copyright (C) 2006-2017 Jacob Mattingley, jem@cvxgen.com.
% The code in this file is Copyright (C) 2006-2017 Jacob Mattingley.
% CVXGEN, or solvers produced by CVXGEN, cannot be used for commercial
% applications without prior written permission from Jacob Mattingley.

% Filename: csolve.m.
% Description: Help file for the Matlab solver interface.
