/* Produced by CVXGEN, 2019-06-21 04:09:48 -0400.  */
/* CVXGEN is Copyright (C) 2006-2017 Jacob Mattingley, jem@cvxgen.com. */
/* The code in this file is Copyright (C) 2006-2017 Jacob Mattingley. */
/* CVXGEN, or solvers produced by CVXGEN, cannot be used for commercial */
/* applications without prior written permission from Jacob Mattingley. */

/* Filename: matrix_support.c. */
/* Description: Support functions for matrix multiplication and vector filling. */
#include "solver.h"
void multbymA(double *lhs, double *rhs) {
}
void multbymAT(double *lhs, double *rhs) {
  lhs[0] = 0;
}
void multbymG(double *lhs, double *rhs) {
  lhs[0] = -rhs[0]*(-1);
  lhs[1] = -rhs[0]*(1);
  lhs[2] = -rhs[0]*(1);
  lhs[3] = -rhs[0]*(1);
}
void multbymGT(double *lhs, double *rhs) {
  lhs[0] = -rhs[0]*(-1)-rhs[1]*(1)-rhs[2]*(1)-rhs[3]*(1);
}
void multbyP(double *lhs, double *rhs) {
  /* TODO use the fact that P is symmetric? */
  /* TODO check doubling / half factor etc. */
  lhs[0] = rhs[0]*(2*(params.a[0]+4*params.b[0]+params.a[0]));
}
void fillq(void) {
  work.q[0] = -2*params.a[0]*(params.pk1[0]-params.p0[0])-2*params.a[0]*(params.pf[0]-params.pk1[0]);
}
void fillh(void) {
  work.h[0] = 0;
  work.h[1] = 0.15;
  work.h[2] = -(0.15+params.pk0[0]-params.pk1[0]);
  work.h[3] = -(params.pk1[0]-(-0.15+params.pk2[0]));
}
void fillb(void) {
}
void pre_ops(void) {
  work.quad_14703251456[0] = (params.pk1[0]-params.p0[0])*(params.pk1[0]-params.p0[0]);
  work.quad_45352259584[0] = (params.pf[0]-params.pk1[0])*(params.pf[0]-params.pk1[0]);
}
