#include "dyros_jet_controller/dyros_jet_model.h"
#include "dyros_jet_controller/walking_controller.h"
#include "cvxgen_6_8_0/cvxgen/solver.h"
#include <stdio.h>


namespace dyros_jet_controller
{

void WalkingController::FootstepUpdateJoystick()
{
    /*//////////////////////////////////////////////////////////////
      *
      * function for calculating foot step when using joystick
      * making 3 steps ahead from current step to make short matrix size
      * first version, only considering fowrad direction and fixed foot step length
      * foot_step_(current_step_number, 6) =0 means swing foot is left( support foot is right)
      * foot_step_(current_step_number, 0)  x foot step where the robot will step right after
      * foot_step matrix has 4 rows (previous step, current, +1, +2 steps)
      * total step number and current_step number will increase while walking command is on
      *///////////////////////////////////////////////////////////////////////////////////

       double dlength = 0.1;// step_length_x_;

       if(walking_tick_ == 0){
           walking_cmd_ = 1;
           foot_step_joy_.resize(5,7);
           foot_step_joy_support_frame_.resize(5,7);
           foot_step_joy_support_frame_offset_.resize(5,7);
           foot_step_joy_.setZero();
           foot_step_joy_support_frame_.setZero();
           foot_step_joy_support_frame_offset_.setZero();

       }

       if(current_step_num_==5){
           walking_cmd_=0;
           total_step_num_joy_ = current_step_num_ +4;
           cout<<"hello"<<endl;
       }
       unsigned int number_of_foot_step;
       number_of_foot_step = 5;
       int temp;
       temp = -1;
       int index =0;

       Eigen::Matrix<double, 5, 7> p_foot_step;
       p_foot_step.setZero();

       if(walking_tick_ ==0 || walking_tick_ == t_start_){
           if(walking_cmd_ == 1)
           {
               if(current_step_num_ <2){
                   for(int i=0;i<number_of_foot_step;i++){
                       temp *= -1;
                       foot_step_joy_(index,0) = dlength*(i+1);
                       foot_step_joy_(index,1) = -temp*0.127794;
                       foot_step_joy_(index,6) = 0.5+0.5*temp;

                       index++;
                   }
               }
               else {
                   p_foot_step = foot_step_joy_;
                   int current_step = (int)current_step_num_;
                   if(!(current_step%2==0.0))
                       temp *= -1;

                   for(int i=0;i<number_of_foot_step;i++){
                       temp*= -1;
    //                   foot_step_joy_(index,0) = p_foot_step(1,0) + dlength*i;
    //                   foot_step_joy_(index,1) = p_foot_step(index,0)*-1;
                       foot_step_joy_(index,0) = dlength * (current_step_num_ + i -1);
                       foot_step_joy_(index,1) = -temp*0.127794;
                       foot_step_joy_(index,6) = 0.5+0.5*temp;

                       index++;
                   }
               }

           }
           else {
                foot_step_joy_ = foot_step_joy_;
           }
           for(int i=0;i<number_of_foot_step;i++){
               file[28]<<walking_tick_ + 30<<"\t"<<current_step_num_<<"\t"<<i<<"\t"<<foot_step_joy_(i,0)<<"\t"<<foot_step_joy_(i,1)<<"\t"<<foot_step_joy_(i,2)<<"\t"<<foot_step_joy_(i,3)<<"\t"<<foot_step_joy_(i,4)<<"\t"<<foot_step_joy_(i,5)<<"\t"<<foot_step_joy_(i,6)<<endl;
           }
       }

}
void WalkingController:: getZmpTrajectory_joystick()
{

  unsigned int planning_step_number  = 3;

  unsigned int norm_size = 0;

  //if(current_step_num_ >= total_step_num_ - planning_step_number)
  if(walking_cmd_==0){
    norm_size = (t_last_-t_start_+1)*(total_step_num_joy_-current_step_num_)+20*hz_;
    cout<<"hello1"<<endl;
  }
  else
    norm_size = (t_last_-t_start_+1)*(planning_step_number);
  if(current_step_num_ == 0)
    norm_size = norm_size + t_temp_+1;
  addZmpOffset();
  zmpGenerator_joystick(norm_size, planning_step_number);
}
void WalkingController::zmpGenerator_joystick(const unsigned int norm_size, const unsigned planning_step_num)
{

//    Eigen::Vector2d zmp_final;

//    zmp_final(0) = ref_zmp_joy_((int)t_total_,0);
//    zmp_final(1) = ref_zmp_joy_((int)t_total_,1);

  //ref_zmp_.resize(norm_size, 2);
  ref_zmp_joy_.resize(norm_size,2);

  com_offset_.setZero();

  Eigen::VectorXd temp_px;
  Eigen::VectorXd temp_py;

  unsigned int index =0;


  if(current_step_num_ ==0)
  {
    for (int i=0; i<= t_temp_; i++) //200 tick
    {
      if(i <= 0.5*hz_)
      {
        ref_zmp_joy_(i,0) = com_support_init_(0)+com_offset_(0);
        ref_zmp_joy_(i,1) = com_support_init_(1)+com_offset_(1);
      }
      else if(i < 1.5*hz_)
      {
        double del_x = i-0.5*hz_;
        ref_zmp_joy_(i,0) = com_support_init_(0)+com_offset_(0)-del_x*(com_support_init_(0)+com_offset_(0))/(1.0*hz_);
        ref_zmp_joy_(i,1) = com_support_init_(1)+com_offset_(1);
      }
      else
      {
        ref_zmp_joy_(i,0) = 0.0;
        ref_zmp_joy_(i,1) = com_support_init_(1)+com_offset_(1);
      }
      index++;
    }
  }
  if(walking_cmd_==0)// walking cmd off
  {
      if(current_step_num_<total_step_num_joy_){
          cout<<"hello2"<<endl;
            for(unsigned int i = current_step_num_; i<total_step_num_joy_ ; i++)
            {
                cout<<"hello3 "<<endl;
             // zmpPattern(i,temp_px1,temp_py);
              onestepZmp(i,temp_px,temp_py);
             // onestepZmp_modified(i,temp_px,temp_py);

              for (unsigned int j=0; j<t_total_; j++)
              {
                ref_zmp_joy_(index+j,0) = temp_px(j);
                ref_zmp_joy_(index+j,1) = temp_py(j);

              }
              index = index+t_total_;
            }

            for (unsigned int j=0; j<20*hz_; j++)
            {
              ref_zmp_joy_(index+j,0) = ref_zmp_joy_(index-1,0);
              ref_zmp_joy_(index+j,1) = ref_zmp_joy_(index-1,1);
            }
            final_ref_zmp_(0) = ref_zmp_joy_(index,0);
            final_ref_zmp_(1) = ref_zmp_joy_(index,1);
            index = index+20*hz_;
      }
      else {
          cout<<"hello4"<<endl;
            for(unsigned int j=0;j<norm_size;j++){
              ref_zmp_joy_(j,0) = final_ref_zmp_(0);
              ref_zmp_joy_(j,1) = final_ref_zmp_(1);
          }
      }
  }
  else
  {
    for(unsigned int i=current_step_num_; i < current_step_num_+planning_step_num; i++)
    {
    //  zmpPattern(i,temp_px1,temp_py);
      onestepZmp(i,temp_px,temp_py);
      //onestepZmp_modified(i,temp_px,temp_py);
      for (unsigned int j=0; j<t_total_; j++)
      {
        ref_zmp_joy_(index+j,0) = temp_px(j);
        ref_zmp_joy_(index+j,1) = temp_py(j);

      }
      index = index+t_total_;
     }
    } //for if(current_step_number_>!!@!@!#~~~~~~~~!
  if(walking_tick_==t_start_){
      file[10]<<walking_tick_<<"\t"<<current_step_num_;
      //file[14]<<walking_tick_;
      for(int i=0;i<norm_size;i++){
          file[10]<<"\t"<<ref_zmp_joy_(i,1);
          //file[14]<<"\t"<<ref_zmp1(i,0);
      }
      //file[14]<<endl;
      file[10]<<endl;
  }

}
void WalkingController::qpIK(){

    // using qpoases
    Eigen::Matrix<double, 12, 12> jacobian_A;
    jacobian_A.setZero();
    jacobian_A.block<6,6>(0,0) = current_leg_jacobian_l_;
    jacobian_A.block<6,6>(6,6) = current_leg_jacobian_r_;

//    Eigen::Matrix<double, 10, 12> jacobian_A;
//    jacobian_A.setZero();
//    jacobian_A.block<5,6>(0,0) = current_leg_jacobian_l_.topRows(5);
//    jacobian_A.block<5,6>(5,6) = current_leg_jacobian_r_.topRows(5);

    if(walking_tick_ == 0){
        cout<<"jacobian left "<<endl<<current_leg_jacobian_l_<<endl;
        cout<<"jacobian right "<<endl<<current_leg_jacobian_r_<<endl;
        cout<<"jacobian combined "<<endl<<jacobian_A<<endl;
    }

//    for(int i= 0;i<6;i++){
//        for(int j=0;j<6;j++){
//            params.A[i + j *6] = current_leg_jacobian_r_(i,j);
//        }
//    }
//    for(int i=0;i<12;i++){
//        for(int j=0;j<12;j++){
//            params.A[i + j*12] = jacobian_A(i,j);
//        }
//    }

//    for(int i=0;i<10;i++){
//        for(int j=0;j<12;j++){
//            params.A[i + j*10] = jacobian_A(i,j);
//        }
//    }

    Eigen::VectorXd y_input(12);
    Eigen::Matrix6d Kp;
    Kp.setIdentity();
    Kp *= 200.0;

    y_input.segment(0,6) = Kp * lp_;
    y_input.segment(6,5) = Kp * rp_;

//    y_input(5) *= 0.5;
//    y_input(11) *= 0.5;

//    for(int i=0;i<10;i++){
//    //    params.Y[i] = rfoot_trajectory_float_.translation()(i) ;
//          params.Y[i] = y_input(i) ;
//    }

    //    for(int i=0;i<12;i++){
    //        for(int j=0;j<12;j++){
    //            params.Q[i+ 12*j] = iden(i,j);
    //        }
    //    }

    Eigen::Matrix12d iden;
    iden.setIdentity();


    real_t H[12*12],A[12*12],b[12*12],lb[12],ub[12], g[12];

    for(int i=0;i<12;i++){
        for(int j=0;j<12;j++){
            H[12*j+i] = iden(i,j);
            A[12*j+i] = jacobian_A(i,j);
        }
    }
    for(int i=0;i<12;i++){
        b[i] = y_input(i);
        lb[i] =-10000000;
        ub[i] = 10000000;
        g[i] = 0.0;
    }

    real_t xOpt[12];

    QProblem example(12,12);

    int_t nWSR = 1000;

    example.init(H,g,A,lb,ub,b,b,nWSR);
    example.getPrimalSolution(xOpt);

    Eigen::Vector12d qp_q;
    for(int i=0;i<6;i++){
        qp_q(i) = xOpt[i]/hz_ + desired_q_not_compensated_[LF_BEGIN + i];
        qp_q(i+6) = xOpt[i+6]/hz_ + desired_q_not_compensated_[RF_BEGIN +i];
    }

   file[7]<<walking_tick_<<"\t"<<qp_q[0]*RAD2DEG<<"\t"<<qp_q[1]*RAD2DEG<<"\t"<<qp_q[2]*RAD2DEG<<"\t"<<qp_q[3]*RAD2DEG<<"\t"<<qp_q[4]*RAD2DEG<<"\t"<<qp_q[5]*RAD2DEG
            <<"\t"<<qp_q[6]*RAD2DEG<<"\t"<<qp_q[7]*RAD2DEG<<"\t"<<qp_q[8]*RAD2DEG<<"\t"<<qp_q[9]*RAD2DEG<<"\t"<<qp_q[10]*RAD2DEG<<"\t"<<qp_q[11]*RAD2DEG<<endl;


}
//void WalkingController::qp2(){
//    //variable vector consists of only zerk

//    double dt = 1.0/hz_;

//    Eigen::Matrix3d A;
//    A.setIdentity();
//    A(0,1) = dt; A(0,2) = pow(dt,2)/2.0;
//    A(1,2) = dt;

//    Eigen::Vector3d b;
//    b(0) = pow(dt,3)/6.0;
//    b(1) = pow(dt,2)/2.0;
//    b(2) = dt;

//    Eigen::Matrix<double, 1, 3>c;
//    c(0) = 1.0; c(1) = 0.0; c(2) = -zc_/GRAVITY;

//    int  NL= (int) 16*hz_/10;
//    NL = 320;
//    Eigen::MatrixXd Px;
//    Px.resize(NL,3);

//    for(int i=0;i<NL;i++){
//        Px(i,0) = 1.0;
//        Px(i,1) = (i+1)*dt;
//        Px(i,2) = (i+1)*(i+1)*dt*dt*0.5-zc_/GRAVITY;
//    }

//    Eigen::MatrixXd Pu;
//    Pu.resize(NL,NL);
//    Pu.setZero();

//    for(int i=0;i<NL;i++){
//        for(int j=0;j<= i;j++){
//            int N = i+1-j;
//            Pu(i,j) = (1+3*N+3*N*N)*pow(dt,3)/6.0 - dt*zc_/GRAVITY;
//        }
//    }

//    Eigen::Vector3d x_0;
//    x_0.setZero();
//    if(walking_tick_ - zmp_start_time_ ==0 && current_step_num_ ==0){
//        x_0(0) = com_support_init_(0);
//    }
//    else {
//        x_0 = x_1_;
//    }
////    x_0(0) = com_support_current_(0);

//    Eigen::VectorXd p_ref;
//    p_ref.resize(NL);
//    double start_time;

//    if(current_step_num_ == 0)
//      start_time = 0;
//    else
//      start_time = t_start_;

//    for(int i=0;i<NL;i++)
//        p_ref(i) = ref_zmp_(walking_tick_ - start_time + i,0);

//    //file[17]<<walking_tick_<<"\t"<<p_ref(0)<<endl;



//    Eigen::VectorXd jerk;
//    jerk.resize(NL);
//    double ratio=0.000001;
//    Eigen::MatrixXd Iden_nl;
//    Iden_nl.resize(NL,NL);
//    Iden_nl.setIdentity();

//    Eigen::MatrixXd p_temp1, p_temp2;
//    p_temp1.resize(NL,NL); p_temp2.resize(NL,NL);

//    Eigen::MatrixXd pu_transpose;
//    pu_transpose.resize(NL,NL);
//    pu_transpose =Pu.transpose();

//    p_temp1 = -(Pu.transpose()*Pu + ratio*Iden_nl).inverse();
//    p_temp2 = p_temp1*pu_transpose;
//    jerk = p_temp2*(Px*x_0-p_ref);

//    Eigen::VectorXd test;
//    test.resize(NL);
//    test = Px*x_0-p_ref;
////    if(walking_tick_ == 300){
////        for(int i=0;i<NL;i++)
////            file[22]<<test(i)<<endl;

////        file[22]<<endl;
////    }

//    //Eigen::Vector3d x_1;

//    x_d1_ = A*x_0 + b*jerk(0);
//   // xd_ =x_1_;

//    if (walking_tick_ == t_start_+t_total_-1 && current_step_num_ != total_step_num_-1)
//    {
//      Eigen::Vector3d com_pos_prev;
//      Eigen::Vector3d com_pos;
//      Eigen::Vector3d com_vel_prev;
//      Eigen::Vector3d com_vel;
//      Eigen::Vector3d com_acc_prev;
//      Eigen::Vector3d com_acc;

//      Eigen::Matrix3d temp_rot;
//      Eigen::Vector3d temp_pos;

//      temp_rot = DyrosMath::rotateWithZ(-foot_step_support_frame_(current_step_num_,5));
//      for(int i=0; i<3; i++)
//        temp_pos(i) = foot_step_support_frame_(current_step_num_,i);

//      //file[26]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;

//      com_pos_prev(0) = x_1_(0);
//      com_pos_prev(1) = ys_(0);
//      com_pos = temp_rot*(com_pos_prev - temp_pos);

//      com_vel_prev(0) = x_1_(1);
//      com_vel_prev(1) = ys_(1);
//      com_vel_prev(2) = 0.0;
//      com_vel = temp_rot*com_vel_prev;

//      com_acc_prev(0) = x_1_(2);
//      com_acc_prev(1) = ys_(2);
//      com_acc_prev(2) = 0.0;
//      com_acc = temp_rot*com_acc_prev;

//      x_1_(0) = com_pos(0);
//      x_1_(1) = com_vel(0);
//      x_1_(2) = com_acc(0);

//     // file[27]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;
//    }

//    file[25]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<"\t"<<x_0(0)<<"\t"<<x_0(1)<<"\t"<<x_0(2)<<"\t"<<jerk(0)<<endl;

//}
void WalkingController::qp3(){
    //variable vector consists of only zerk possible one. using analytic method for jerk

    double dt = 1.0/hz_;

    int  NL= (int) 16*hz_/10;
    NL = 320;

    int N = 160;
    int interval = NL/N;

    if(walking_tick_ ==0){
        ObtainMatrix(NL,N,dt,interval);
    }


    Eigen::Vector3d x_0, y_0;
    x_0.setZero(); y_0.setZero();
    if(walking_tick_ - zmp_start_time_ == 0 && current_step_num_ ==0){
        x_0(0) = com_support_init_(0);
        y_0(0) = com_support_init_(1);
    }
    else {
        x_0 = x_p1_;
        y_0 = y_p1_;
    }

//    if(walking_tick_ == 920){
//        x_0(0) -= 0.03;
//        x_0(1) -= 0.03;
//    }

//    x_0(0) = com_support_current_(0);

    Eigen::MatrixXd p_ref;
    p_ref.resize(N,2);
    double start_time;

    if(current_step_num_ == 0)
      start_time = 0;
    else
      start_time = t_start_;

    for(int i=0;i<N;i++){//column 0 = x, column 1 =y
        p_ref(i,0) = ref_zmp_(walking_tick_ - start_time + interval*i,0); // x position of foot
        p_ref(i,1) = ref_zmp_(walking_tick_ - start_time + interval*i,1); // y position of foot
    }

    //file[17]<<walking_tick_<<"\t"<<p_ref(0,0)<<"\t"<<p_ref(0,1)<<endl;



    Eigen::VectorXd foot_x, foot_y;

    footReferenceGenerator(foot_x, foot_y);

    Eigen::VectorXd fx_ref, fy_ref;
    fx_ref.resize(N); fy_ref.resize(N);

    for(int i=0;i<N;i++){
        fx_ref(i) = foot_x(walking_tick_-start_time +interval*i);
        fy_ref(i) = foot_y(walking_tick_-start_time +interval*i);
    }



    Eigen::MatrixXd support_x,support_y,tempx,tempy;
    support_x.resize(N,2);
    support_y.resize(N,2);

    GetSupportPolygon(tempx,tempy);

    for(int i=0;i<N;i++){
        support_x(i,0) = tempx(walking_tick_-start_time,0);
        support_x(i,1) = tempx(walking_tick_-start_time,1);

        support_y(i,0) = tempy(walking_tick_-start_time,0);
        support_y(i,1) = tempy(walking_tick_-start_time,1);
    }

    //file[26]<<walking_tick_<<"\t"<<support_x(0,0)<<"\t"<<support_x(0,1)<<"\t"<<support_y(0,0)<<"\t"<<support_y(0,1)<<endl;

    if(walking_tick_ == t_start_){
        file[26]<<walking_tick_;
        for(int i=0;i<N;i++)
            file[26]<<"\t"<<fx_ref(i);
        file[26]<<endl;

        file[26]<<walking_tick_;
        for(int i=0;i<N;i++)
            file[26]<<"\t"<<fy_ref(i);
        file[26]<<endl;

    }




    Eigen::MatrixXd px_x, px_x_to_foot, py_y, py_y_to_foot;
    px_x.resize(N,1); px_x_to_foot.resize(N,1); py_y.resize(N,1); py_y_to_foot.resize(N,1);
    px_x = Px_*x_0;
    py_y = Py_*y_0;

    px_x_to_foot = px_x - fx_ref;
    py_y_to_foot = py_y - fy_ref;

    Eigen::VectorXd jerk_x, jerk_y;
    jerk_x.resize(N); jerk_y.resize(N);
    //jerk = p_temp2*(Px*x_0-p_ref);
    //jerk = p_temp_*(px_x - p_ref);
    Eigen::VectorXd temp_x, temp_y;
    temp_x.resize(N);
    temp_x = pu_t_*(px_x - p_ref.col(0));
    temp_x = alpha_x_ *(pu_t_*(px_x - fx_ref));

    temp_y = pu_t_*(py_y - p_ref.col(1));
    temp_y = alpha_y_*(pu_t_*(py_y - fy_ref));
    //temp_temp += coef_x_*x_0;
    //jerk = -coef_inverse_*temp_temp;

    temp_x += Velocity_delta_x_*x_0;
    temp_y += Velocity_delta_y_*y_0;

    jerk_x = - Qx_inverse_*temp_x;
    jerk_y = - Qy_inverse_*temp_y;

//    // for using variance
//    temp_temp = alpha_*pu_t_*px_x_to_foot;
//    temp_temp += beta_*bv_variance_.transpose()*Av_variance_*x_0/N;

//    jerk = -Q_variance_inverse_*temp_temp;


//    Eigen::VectorXd test;
//    test.resize(N);
//    test = Px*x_0-p_ref;
//    if(walking_tick_ == 300){
//        for(int i=0;i<N;i++)
//            file[22]<<test(i)<<endl;

//        file[22]<<endl;
//    }

    // consider x velocity


    ///////////////////////////////////////////////////////////////////////////////
    ///                                                                   /////////
    /// for using qpoases,                                                ////////
    /// minimize zmp to foot position, velocity delta and jerk input          ////
    ///                                                                      /////
    ///////////////////////////////////////////////////////////////////////////////

    Eigen::MatrixXd temp_margin_x, temp_margin_y;
    calculateFootMargin(temp_margin_x,temp_margin_y);

    Eigen::MatrixXd cst_x, cst_y;
    cst_x.resize(N,2); cst_y.resize(N,2);

    for(int i=0;i<N;i++){
        cst_x(i,0) = temp_margin_x(walking_tick_-start_time+interval*i,0);
        cst_x(i,1) = temp_margin_x(walking_tick_-start_time+interval*i,1);

        cst_y(i,0) = temp_margin_y(walking_tick_-start_time+interval*i,0);
        cst_y(i,1) = temp_margin_y(walking_tick_-start_time+interval*i,1);

//        cst_x(i,0) = temp_margin_x(i,0);
//        cst_x(i,1) = temp_margin_x(i,1);

//        cst_y(i,0) = temp_margin_y(i,0);
//        cst_y(i,1) = temp_margin_y(i,1);
    }

    Eigen::MatrixXd Px_zmp, Px_vel, Py_zmp(N,1), Py_vel(N,1);
    Px_zmp.resize(N,1); Px_vel.resize(N,1);


    Eigen::MatrixXd selec_v_x, selec_v_y(N,1);
    selec_v_x.resize(N,1);
    selec_v_x = selec_delta_v_*x_0; //selec_delta_v_ = Selec_delta_*Av_ - Av0_;
    selec_v_y = selec_delta_v_*y_0;

    Px_zmp = pu_.transpose()*px_x_to_foot;
    //Px_vel = selec_bv_.transpose()*selec_v_x;
    Px_vel = selec_v_x.transpose()*selec_bv_;
    //P_vel = selec_delta_v_.transpose()*selec_bv_;
    Py_zmp = pu_.transpose()*py_y_to_foot;
    Py_vel = selec_v_y.transpose()*selec_bv_;

    Eigen::MatrixXd px_input, py_input;
    px_input.resize(N,1); py_input.resize(N,1);

    px_input = alpha_x_*Px_zmp + beta_x_*Px_vel; // for delta velocity
    py_input = alpha_y_*Py_zmp + beta_y_*Py_vel;

    Eigen::MatrixXd px_variance, py_variance;
    px_variance.resize(1,N); py_variance.resize(1,N);
    Eigen::MatrixXd tempx_var(N,1), tempy_var(N,1);

    //tempx_var.resize(N,1);
    tempx_var = Av_variance_*x_0;
    tempy_var = Av_variance_*y_0;

    px_variance = tempx_var.transpose()*bv_variance_;
    py_variance = tempy_var.transpose()*bv_variance_;


    //px_input = alpha_x_*px_x_to_foot.transpose()*pu_ + beta_x_*px_variance/N;
    //py_input = alpha_y_*py_y_to_foot.transpose()*pu_ + beta_y_*py_variance/N;

    // making full size qp fomulation ///
    Eigen::MatrixXd Qu(2*N,2*N), Au(2*N,2*N), gu(2*N,1);
    Qu.setZero(); Au.setZero(); gu.setZero();
    Qu.block(0,0,N,N) = Qx_;
    Qu.block(N,N,N,N) = Qy_;

//    Qu.block(0,0,N,N) = Q_variance_;
//    Qu.block(N,N,N,N) = Q_variance_;

    Au.block(0,0,N,N) = pu_;
    Au.block(N,N,N,N) = pu_;

    gu.block(0,0,N,1) = px_input;
    gu.block(N,0,N,1) = py_input;


    real_t Qx_input[N*N], gx_input[N], lbx[N],ubx[N], Ax_input[N*N], lbAx[N],ubAx[N];
    real_t Qy_input[N*N], gy_input[N], lby[N],uby[N], Ay_input[N*N], lbAy[N],ubAy[N];

    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            Qx_input[j*N +i] = Qx_(i,j); // for delta velocity
            Ax_input[j*N+i] = pu_(i,j); // matrix for Jerk
            //Qx_input[j*N+i] = Q_variance_(i,j);

            Ay_input[j*N+i] = pu_(i,j);
            //Qy_input[j*N+i] = Q_variance_(i,j);
            Qy_input[j*N+i] = Qy_(i,j);

        }
         gx_input[i] = px_input(i);
         gy_input[i] = py_input(i);
       // g_input[i] = p_variance(i);

         lbx[i] = -10;
         ubx[i] = 10;

         lby[i] = -10;
         uby[i] = 10;
//        lbA[i] = -0.15-px_x_to_foot(i);
//        ubA[i] = 0.15-px_x_to_foot(i);
//        lbA[i] = cst_x(i,0) -px_x_to_foot(i);
//        ubA[i] = cst_x(i,1) - px_x_to_foot(i);

         lbAx[i] = cst_x(i,0) -px_x_to_foot(i);
         ubAx[i] = cst_x(i,1) - px_x_to_foot(i);

         lbAy[i] = cst_y(i,0) -py_y_to_foot(i);
         ubAy[i] = cst_y(i,1) - py_y_to_foot(i);
    }

//    if(walking_tick_ == 800){
//        fx_ref(0) = 0.0;
//        fy_ref(0) = -0.065;
//    }

    if(walking_tick_ >= 799 && walking_tick_ <= 802){
        cout<<"walking tick : "<<walking_tick_<<",  "<<fx_ref(0)<<", "<<fy_ref(0)<<endl;
    }

    file[17]<<walking_tick_<<"\t"<<lbAx[0]<<"\t"<<ubAx[0]<<"\t"<<lbAy[0]<<"\t"<<ubAy[0]<<"\t"<<cst_x(0,0)<<"\t"<<cst_x(0,1)<<"\t"<<cst_y(0,0)<<"\t"<<cst_y(0,1)<<"\t"<<fx_ref(0)<<"\t"<<fy_ref(0)<<endl;
    // for full size qp fomulation
    real_t Qu_input[2*N*2*N], gu_input[2*N], lbu[2*N],ubu[2*N],Au_input[2*N*2*N],lbAu[2*N],ubAu[2*N];

    for(int i=0;i<2*N;i++){
        for(int j=0;j<2*N;j++){
            Qu_input[j*2*N+i] = Qu(i,j);
            Au_input[j*2*N+i] = Au(i,j);
        }
        gu_input[i] = gu(i,0);
        lbu[i] = -10;
        ubu[i] = 10;
    }
    for(int i=0;i<N;i++){
        lbAu[i] = cst_x(i,0) - px_x_to_foot(i);
        ubAu[i] = cst_x(i,1) - px_x_to_foot(i);

        lbAu[N+i] = cst_y(i,0) - py_y_to_foot(i);
        ubAu[N+i] = cst_y(i,1) - py_y_to_foot(i);
    }

//    if(walking_tick_ ==0|| walking_tick_ == t_start_){
//        for(int i=0;i<N;i++){
//            file[22]<<"\t"<<cst_y(i,0);
//            file[23]<<"\t"<<cst_y(i,1);
//        }
//        file[22]<<endl;
//        file[23]<<endl;
//    }


    /////////////////////////end of matrix for qpoases///////////////////////////////////////

    int_t nV;
    nV = N;
    //QProblemB mpc(nV);
    QProblem mpc(nV,nV);
    Options op;
    op.printLevel = PL_NONE;
    op.initialStatusBounds = ST_INACTIVE;
    op.numRefinementSteps = 1;
    op.enableCholeskyRefactorisation = 1;
    mpc.setOptions(op);
    int_t nWSR = 100;

    real_t xopt[N];

//    mpc.init(Qx_input,gx_input,Ax_input,lbx,ubx,lbAx,ubAx,nWSR);
//    mpc.getPrimalSolution(xopt);

//    //mpc.hotstart(g_input,lb,ub,nWSR,0);
//    mpc.hotstart(gx_input,lbx,ubx,lbAx,ubAx,nWSR);
//    mpc.getPrimalSolution(xopt);

    real_t yopt[N];
    QProblem mpc_y(nV,nV);
    Options op1;
    op1.printLevel = PL_NONE;
    op1.initialStatusBounds = ST_INACTIVE;
    op1.numRefinementSteps = 1;
    op1.enableCholeskyRefactorisation = 1;

//    mpc_y.setOptions(op1);

//    mpc_y.init(Qy_input,gy_input,Ay_input,lby,uby,lbAy,ubAy,nWSR);
//    mpc_y.getPrimalSolution(yopt);


//    //mpc.hotstart(g_input,lb,ub,nWSR,0);
//    mpc_y.hotstart(gy_input,lby,uby,lbAy,ubAy,nWSR);
//    mpc_y.getPrimalSolution(yopt);





    int_t nVu = 2*N;


    QProblem mpc_u(nVu,nVu);

    real_t xopt_u[nVu];

    mpc_u.setOptions(op);
    mpc_u.init(Qu_input,gu_input,Au_input,lbu,ubu,lbAu,ubAu, nWSR);
    mpc_u.getPrimalSolution(xopt_u);

    mpc_u.hotstart(gu_input,lbu,ubu,lbAu,ubAu,nWSR);
    mpc_u.getPrimalSolution(xopt_u);


//    x_1_ = A_*x_0 + b1_*jerk_x(0);
//    y_1_ = A_*y_0 + b1_*jerk_y(0);
//    x_d1_ = A_*x_0 + b1_*xopt[0];
//    y_d1_ = A_*y_0 + b1_*yopt[0];
    x_d1_ = A_*x_0 + b1_*xopt_u[0];
    y_d1_ = A_*y_0 + b1_*xopt_u[N];


    //    Eigen::VectorXd x_opt(N), y_opt(N);
    //    for(int i=0;i<N;i++){
    //        x_opt(i) = xopt_u[i];
    //        y_opt(i) = xopt_u[i+N];
    //    }

    Eigen::MatrixXd boundarycheck;
    boundarycheck.resize(N,1);

//    for(int i=0;i<N;i++)
//        boundarycheck(i) = xopt[i];

//    boundarycheck = pu_*boundarycheck;

//    if(walking_tick_ ==0||walking_tick_ ==t_start_){
//        for(int i=0;i<N;i++){
//            file[27]<<lbA[i]<<"\t"<<ubA[i]<<"\t"<<boundarycheck(i)<<endl;

//        }
//    }
///////////////////////////////////////////
    /// check
    ///
    Eigen::VectorXd temp1, temp2, temp3;
    temp1.resize(N,1); temp2.resize(N,1); temp3.resize(N,1);

    temp1 = px_x_to_foot + pu_*jerk_x;
    temp2 = selec_delta_v_*x_0 + selec_bv_*jerk_x;
    temp3 = jerk_x;

    Eigen::Matrix<double, 1, 1> optvalue;

    //optvalue = 0.5*alpha_*temp1.transpose()*temp1 + 0.5*beta_*temp2.transpose()*temp2 + 0.5*gamma_*jerk_x.transpose()*jerk_x;

    Eigen::Matrix<double, 1, 3>c;
    c(0) = 1.0; c(1) = 0.0; c(2) = -zc_/GRAVITY;
    double zmp_x, zmp_y;

    Eigen::VectorXd sol_opt(nVu);
    double pux, puy;
    //Eigen::VectorXd puy(1);

    for(int i=0;i<nVu;i++)
        sol_opt(i) = xopt_u[i];

    pux = Au.row(0)*sol_opt;
    puy = Au.row(N)*sol_opt;

    zmp_x = c*x_d1_;
    zmp_y = c*y_d1_;

    ///////////////////////////////////

    x_p1_ = x_d1_;
    y_p1_ = y_d1_;


    file[25]<<walking_tick_<<"\t"<<x_d1_(0)<<"\t"<<x_d1_(1)<<"\t"<<x_d1_(2)<<"\t"<<y_d1_(0)<<"\t"<<y_d1_(1)<<"\t"<<y_d1_(2)
           <<"\t"<<xopt_u[0]<<"\t"<<xopt_u[N]
          <<"\t"<<pux<<"\t"<<puy<<endl;//"\t"<<zmp_x<<"\t"<<zmp_y<<endl;//<<"\t"<<pux<<"\t"<<puy<<"\t"<<xopt[0]<<"\t"<<yopt[0]<<"\t"<<xopt_u[0]<<"\t"<<xopt_u[N]<<endl;//"\t"<<yopt[0]<<endl;//<<"\t"<<mpc.getObjVal()<<"\t"<<optvalue<<"\t"<<fx_ref(0)<<  endl;//<<xOpt[0]<<endl;

    SupportfootComUpdate();




}
void WalkingController::calculateFootMargin(Eigen::MatrixXd& margin_x, Eigen::MatrixXd& margin_y){
    unsigned int norm_size=0;
    if(current_step_num_ >= total_step_num_ - 3)
      norm_size = (t_last_-t_start_+1)*(total_step_num_-current_step_num_)+20*hz_;
    else
      norm_size = (t_last_-t_start_+1)*3;
    if(current_step_num_ == 0)
      norm_size = norm_size + t_temp_+1;

    margin_x.resize(norm_size,2); margin_y.resize(norm_size,2);

    //width of foot is 0.172, length of foot is 0.3

    //column 0 is lower bound column 1 is upper condition
    unsigned int index =0;
    if(current_step_num_ ==0){
      //  cout<<"hellot at foot margin  "<<walking_tick_<<endl;
        for(int i=0;i<t_temp_;i++){
            margin_x(i,0) = 0;
            margin_x(i,1) = 0.15; //original 0.05

            margin_y(i,0) = -0.05;
            margin_y(i,1) = 0.05;

            index++;
        }
    }
    if(current_step_num_ >= total_step_num_-3){
        for(unsigned int i=current_step_num_;i<total_step_num_;i++){
            if(i >= total_step_num_-1){
                for(unsigned int j=0;j<t_total_;j++){
                    margin_x(index+j,0) = 0.0;
                    margin_x(index+j,1) = 0.0;

//                    margin_y(index+j,0) = 0.0;
//                    margin_y(index+j,1) = 0.0;
                    if(foot_step_(i,6) ==1)// left foot support
                    {
                        margin_y(index+j,0) = -0.04;
                        margin_y(index+j,1) = -0.02;//0.02; //done
//                        margin_y(index+j,0) = -0.08;//-0.08;
//                        margin_y(index+j,1) = -0.02;//0.0;//-0.04;//0.02;
                    }
                    else //right foot support
                    {
                        margin_y(index+j,0) = 0.02;//-0.02;
                        margin_y(index+j,1) = 0.04; //done
//                        margin_y(index+j,0) = 0.02;//0.0;//0.04;//-0.02;
//                        margin_y(index+j,1) = 0.08;//0.08;
                    }
                }
            }
            else {
                for(unsigned int j=0;j<t_total_;j++){
                    margin_x(index+j,0) = -0.15; // original 0.1
                    margin_x(index+j,1) = 0.15;

//                    margin_y(index+j,0) = -0.05;
//                    margin_y(index+j,1) = 0.05;
                    if(foot_step_(i,6) ==1)// left foot support
                    {
                        margin_y(index+j,0) = -0.04;//ok margin down -0.04 magin up -0.02
                        margin_y(index+j,1) = -0.02;//0.02;
//                        margin_y(index+j,0) = -0.08;//-0.08;
//                        margin_y(index+j,1) = -0.02;//0.0;//-0.04;//0.02;
                    }
                    else //right foot support
                    {
                        margin_y(index+j,0) = 0.02;//-0.02;
                        margin_y(index+j,1) = 0.04;//ok margin up 0.04 magin down 0.02
//                        margin_y(index+j,0) = 0.08;//0.04;//-0.02;
//                        margin_y(index+j,1) = 0.02;//0.08;
                    }
                }
            }
            index = index+t_total_;
        }
        for(unsigned int j=0;j<20*hz_;j++){
            margin_x(index+j,0) = margin_x(index-1,0);
            margin_x(index+j,1) = margin_x(index-1,1);

            margin_y(index+j,0) = margin_y(index-1,0);
            margin_y(index+j,1) = margin_y(index-1,1);
        }
        index = index+20*hz_;
    }
    else {
//        if(current_step_num_==0)
//            cout<<"hellot at foot margin 22 "<<walking_tick_<<endl;

        for(unsigned int i=current_step_num_;i<current_step_num_+3;i++){
            for(unsigned int j=0;j<t_total_;j++){
                margin_x(index+j,0) = -0.15;
                margin_x(index+j,1) = 0.15; // original 0.1

//                margin_y(index+j,0) = -0.05;
//                margin_y(index+j,1) = 0.05;
                if(foot_step_(i,6) ==1)// left foot support
                {
                    margin_y(index+j,0) = -0.04; //ok margin down -0.04 magin up -0.02
                    margin_y(index+j,1) = -0.02;//0.02;
//                    margin_y(index+j,0) = -0.08;
//                    margin_y(index+j,1) = -0.02;//0.02;
                }
                else //right foot support
                {
                    margin_y(index+j,0) = 0.02;//-0.02;
                    margin_y(index+j,1) = 0.04;//ok margin up 0.04 magin down 0.02
//                    margin_y(index+j,0) = 0.02;//-0.02;
//                    margin_y(index+j,1) = 0.08;
                }
            }
            index = index+ t_total_;
        }
    }
}
void WalkingController::footReferenceGenerator(Eigen::VectorXd& foot_x, Eigen::VectorXd& foot_y){
    unsigned int norm_size=0;
    if(current_step_num_ >= total_step_num_ - 3)
      norm_size = (t_last_-t_start_+1)*(total_step_num_-current_step_num_)+20*hz_;
    else
      norm_size = (t_last_-t_start_+1)*3;
    if(current_step_num_ == 0)
      norm_size = norm_size + t_temp_+1;

    foot_x.resize(norm_size);
    foot_y.resize(norm_size);


    Eigen::VectorXd temp_f_x, temp_f_y;

    unsigned int index=0;
    if(current_step_num_ ==0){
        for(int i=0;i<t_temp_;i++){
            if(i<= 0.5*hz_){
                foot_x(i) = com_support_init_(0) + com_offset_(0);
                foot_y(i) = com_support_init_(1) + com_offset_(1);
            }
            else if(i<1.0*hz_){
                foot_x(i) = 0.0;
                foot_y(i) = com_support_init_(1) + com_offset_(1);
            }
            else{
                foot_x(i) = 0.0;
                foot_y(i) = com_support_init_(1) + com_offset_(1);
            }
            index++;
        }
    }
    if(current_step_num_ >= total_step_num_-3){
        for(unsigned int i=current_step_num_;i<total_step_num_;i++){
            onestepFoot(i,temp_f_x, temp_f_y);
            for(unsigned int j=0;j<t_total_;j++){
                foot_x(index+j) = temp_f_x(j);
                foot_y(index+j) = temp_f_y(j);
            }

            index = index+t_total_;
        }
        for(unsigned int j=0;j<20*hz_;j++){
            foot_x(index+j) = 0.0;//foot_x(index-1);
           // foot_y(index+j) = foot_y(index-1);
            foot_y(index+j) = (foot_step_support_frame_(current_step_num_,1) + foot_step_support_frame_(current_step_num_-1,1))/2;
        }

        index = index+20*hz_;
    }
    else{
        for(unsigned int i=current_step_num_;i<current_step_num_+3;i++){
            onestepFoot(i,temp_f_x, temp_f_y);
            for(unsigned int j=0;j<t_total_;j++){
                foot_x(index+j) = temp_f_x(j);
                foot_y(index+j) = temp_f_y(j);
            }

            index = index+t_total_;
        }
    }
    if(walking_tick_==t_start_){
        cout<<"in qpotp controoler : "<<foot_step_support_frame_offset_(current_step_num_-1,1)<<endl;
        if(current_step_num_ == total_step_num_-1)
            cout<<"in qp end"<<(foot_step_support_frame_(current_step_num_,1) + foot_step_support_frame_(current_step_num_-1,1))/2;
        file[27]<<walking_tick_;
        for(int i=0;i<norm_size;i++){
            file[27]<<"\t"<<foot_x(i);
        }
        file[27]<<endl;
        file[27]<<current_step_num_;
        for(int i=0;i<norm_size;i++){
            file[27]<<"\t"<<foot_y(i);
        }
        file[27]<<endl;

    }

}
void WalkingController::onestepFoot(unsigned int current_step_number, Eigen::VectorXd& temp_f_x, Eigen::VectorXd& temp_f_y){
    temp_f_x.resize((int)t_total_);
    temp_f_x.setZero();

    temp_f_y.resize((int)t_total_);
    temp_f_y.setZero();

    if(current_step_number ==0){
        for(int i=0;i<t_total_;i++)
        {
            temp_f_x(i) = supportfoot_support_init_offset_(0);
            temp_f_y(i) = supportfoot_support_init_offset_(1);
            if(foot_step_(current_step_number,6) ==1) //left foot support
                temp_f_y(i) = supportfoot_support_init_offset_(1)-0.025;
            else {
                temp_f_y(i) = supportfoot_support_init_offset_(1)+0.025; //ok
            }
        }
    }
//    else if(current_step_number == total_step_num_-1){
//        for(int i=0;i<t_total_;i++){
//            temp_f_x(i) = foot_step_support_frame_(current_step_number,0);
//            temp_f_y(i) = foot_step_support_frame_(current_step_number,1);//(foot_step_support_frame_(current_step_number,1) + foot_step_support_frame_(current_step_num_-1,1))/2;
//        }
//    }
    else{
        for(int i=0;i<t_total_;i++){
            temp_f_x(i) = foot_step_support_frame_offset_(current_step_number-1,0);
            temp_f_y(i) = foot_step_support_frame_offset_(current_step_number-1,1);
            if(foot_step_(current_step_number,6) ==1) //left foot support
                temp_f_y(i) =foot_step_support_frame_offset_(current_step_number-1,1)-0.025;
            else {
                temp_f_y(i) = foot_step_support_frame_offset_(current_step_number-1,1)+0.025; // ok
            }
        }
    }

}
void WalkingController::ObtainMatrix(int NL, int N, double dt, int interval){
    Eigen::Matrix3d A;
    A.setIdentity();
    A(0,1) = dt; A(0,2) = pow(dt,2)/2.0;
    A(1,2) = dt;
    A_ = A;
    Eigen::Vector3d b;
    b(0) = pow(dt,3)/6.0;
    b(1) = pow(dt,2)/2.0;
    b(2) = dt;
    b1_ = b;
    Eigen::Matrix<double, 1, 3>c;
    c(0) = 1.0; c(1) = 0.0; c(2) = -zc_/GRAVITY;

    Eigen::MatrixXd px_full(NL,3);
    Eigen::MatrixXd pu_full(NL,NL);
    pu_full.setZero();

    //px matrix full size ///
    for(int i=0;i<NL;i++){
        px_full(i,0) = 1.0;
        px_full(i,1) = (i+1)*dt;
        px_full(i,2) = (i+1)*(i+1)*dt*dt*0.5-zc_/GRAVITY;
    }
     // pu matrix full size
    for(int i=0;i<NL;i++){
        for(int j=0;j<= i;j++){
            int nl = i - j;
            pu_full(i,j) = (1+3*nl+3*nl*nl)*pow(dt,3)/6.0 - dt*zc_/GRAVITY;
        }
    }

    //Eigen::MatrixXd Px;


    Px_.resize(N,3);
    Py_.resize(N,3);
    for(int i=0;i<N;i++){
        Px_(i,0) = 1.0;
        Px_(i,1) = (interval*i+1)*dt;
        Px_(i,2) = (interval*i+1)*(interval*i+1)*dt*dt*0.5-zc_/GRAVITY;
    }


//    for(int i=0;i<N;i++){
//        Px_.row(i) = px_full.row(i*interval);
//    }
    Py_ = Px_;

    Eigen::MatrixXd Pu;
    Pu.resize(N,N);
    Pu.setZero();

    for(int i=0;i<N;i++){
        for(int j=0;j<= i;j++){
            int nl = interval*i + 1-j;
            Pu(i,j) = (1+3*nl+3*nl*nl)*pow(dt,3)/6.0 - dt*zc_/GRAVITY;
        }
    }
//    for(int i=0;i<N;i++){
//        Pu.row(i) = pu_full.row(interval*i);
//    }
    pu_t_.resize(N,N);
    pu_t_ = Pu.transpose();

    double ratio=0.000001;
    Eigen::MatrixXd Iden_nl;
    Iden_nl.resize(N,N);
    Iden_nl.setIdentity();

    Eigen::MatrixXd p_temp1, p_temp2;
    p_temp1.resize(N,N); p_temp2.resize(N,N);

    Eigen::MatrixXd pu_transpose;
    pu_transpose.resize(N,N);
    pu_transpose =Pu.transpose();

    pu_.resize(N,N);
    pu_ = Pu;
    Eigen::MatrixXd pu_h;
    pu_h.resize(N,N);
    pu_h = Pu.transpose()*Pu + ratio*Iden_nl;

    p_temp1 = -pu_h.inverse();
    p_temp2 = p_temp1*pu_transpose;

    p_temp_.resize(N,N);
    p_temp_ = p_temp2;

    Eigen::MatrixXd pu_t_pu;
    pu_t_pu.resize(N,N);
    pu_t_pu.setZero();

    pu_t_pu = pu_transpose*Pu;

    Eigen::MatrixXd bk_full(3*NL,NL);
    bk_full.setZero();
    for(int i=0;i<NL;i++){
        for(int j=0;j<=i;j++){
            int n=i-j;
            bk_full(3*i,j) = (1+3*n*(n+1))/6.0 * pow(dt,3);
            bk_full(3*i+1,j) = (2*n+1)/2.0 *pow(dt,2);
            bk_full(3*i+2,j) = dt;
        }
    }

    bk_.resize(3*N,N);
    bk_.setZero();
    for(int i=0;i<N;i++){
        for(int j=0;j<=i;j++){
            int n = i-j;
         bk_(3*i,j) = (1+3*n*(n+1))/6.0 * pow(dt,3);
         bk_(3*i+1,j) = (2*n+1)/2.0 *pow(dt,2);
         bk_(3*i+2,j) = dt;
        }
    }
//    for(int i=0;i<N;i++){
//        bk_.row(i) = bk_full.row(i*interval);
//    }

//    for(int i=0;i<3*N;i++){
//        for(int j=0;j<N;j++)
//            file[17]<<bk_(i,j)<<"\t";

//        file[17]<<endl;
//    }


    Eigen::MatrixXd Ak_full(3*NL,3);
    for(int i=0;i<NL;i++){
        Ak_full(3*i,0) = 1.0;
        Ak_full(3*i,1) = (i+1)*dt;
        Ak_full(3*i,2) = (i+1)*(i+1)/2.0 * pow(dt,2);

        Ak_full(3*i+1,1) = 1.0;
        Ak_full(3*i+1,2) =(i+1)*dt;

        Ak_full(3*i+2,2) = 1.0;
    }
    Ak_.resize(3*N,3);
    Ak_.setZero();
    for(int i=0;i<N;i++){
        Ak_(3*i,0) = 1.0;
        Ak_(3*i,1) = (i+1)*dt;
        Ak_(3*i,2) = (i+1)*(i+1)/2.0 * pow(dt,2);

        Ak_(3*i+1,1) = 1.0;
        Ak_(3*i+1,2) =(i+1)*dt;

        Ak_(3*i+2,2) = 1.0;
    }
//    for(int i=0;i<N;i++){
//        Ak_.row(i) = Ak_full.row(i*interval);
//    }
//    for(int i=0;i<3*N;i++){
//        for(int j=0;j<3;j++)
//            file[16]<<Ak_(i,j)<<"\t";

//        file[16]<<endl;
//    }


    if(walking_tick_ ==0){
        file[14]<<walking_tick_;
        file[24]<<walking_tick_;
        for(int i=0;i<NL;i++){
            file[14]<<"\t"<<px_full(i,0)<<"\t"<<px_full(i,1)<<"\t"<<px_full(i,2)<<endl;
            for(int j=0;j<NL;j++){
                file[15]<<pu_full(i,j)<<"\t";
            }
            file[15]<<endl;
        }
        file[16]<<walking_tick_;
        for(int i=0;i<3*NL;i++){
            for(int j=0;j<NL;j++){
                file[16]<<"\t"<<bk_full(i,j);
            }
            file[24]<<"\t"<<Ak_full(i,0)<<"\t"<<Ak_full(i,1)<<"\t"<<Ak_full(i,2)<<endl;
            file[16]<<endl;
        }

    }

    coef_inverse_.resize(N,N);
    Eigen::MatrixXd coef_temp;
    coef_temp.resize(N,N);

    double alp = 0.1;

    Eigen::MatrixXd selec;
    selec.resize(N,3*N);
    selec.setZero();

    Eigen::Matrix<double, 1, 3> selec_velocity;
    selec_velocity.setZero();
    selec_velocity(0,1) = 1.0;

    for(int i=0;i<N;i++)
        selec.block<1,3>(i,3*i) = selec_velocity;

    Eigen::MatrixXd temp_bk_s_t, temp_s_bk;
    temp_bk_s_t.resize(N,N); temp_s_bk.resize(N,N);

    temp_bk_s_t = bk_.transpose()*selec.transpose();
    temp_s_bk = selec*bk_;

    Eigen::MatrixXd temp_bk_s_s_bk;
    temp_bk_s_s_bk.resize(N,N);
    temp_bk_s_s_bk = temp_bk_s_t*temp_s_bk;

    coef_temp = pu_h + alp*temp_bk_s_s_bk;

    coef_inverse_ = coef_temp.inverse();

    coef_x_.resize(N,3*N);
    coef_x_ = alp*temp_bk_s_t*selec *Ak_;

    // for using delta_velocity
    Av_.resize(N,3);
    Av_.setZero();

    bv_.resize(N,N);
    bv_.setZero();

    Av0_.resize(N,3);
    Av0_.setZero();

    Av_ = selec*Ak_;
    bv_ = selec*bk_;

    Av0_(0,1) = 1.0;

    Selec_delta_.resize(N,N);
    Selec_delta_.setZero();
    Eigen::Matrix<double, 1, 2> del_vel;
    del_vel(0,0) = -1.0; del_vel(0,1) = 1.0;

    Selec_delta_(0,0) = 1.0;

    for(int i=1;i<N;i++)
        Selec_delta_.block<1,2>(i,i-1) =del_vel;

    Qx_inverse_.resize(N,N);    Qx_inverse_.setZero();
    Qy_inverse_.resize(N,N);    Qy_inverse_.setZero();

    beta_x_ = 1.0;//0.000001;
    beta_y_ = 0.000001;//0.000001;//0.000001;
    Eigen::MatrixXd sdelta_bv,Qx_temp, Q_v, Qy_temp;
    sdelta_bv.resize(N,N); bvt_sdeltat_.resize(N,N); Qx_temp.resize(N,N);Qy_temp.resize(N,N); Q_v.resize(N,N);

    sdelta_bv = Selec_delta_*bv_;
    bvt_sdeltat_ = sdelta_bv.transpose();

    selec_bv_.resize(N,N);
    selec_bv_.setZero();
    selec_bv_ = sdelta_bv;

    Q_v = bvt_sdeltat_*sdelta_bv;
    Qx_temp = pu_h + beta_x_*Q_v;
    Qx_inverse_ = Qx_temp.inverse();

    Qy_temp = pu_h + beta_y_*Q_v;
    Qy_inverse_ = Qy_temp.inverse();


    selec_delta_v_.resize(N,3);
    selec_delta_v_ = Selec_delta_*Av_ - Av0_;

    Velocity_delta_x_.resize(N,3);    Velocity_delta_y_.resize(N,3);

    Velocity_delta_x_ = beta_x_*bvt_sdeltat_*selec_delta_v_;
    Velocity_delta_y_ = beta_y_*bvt_sdeltat_*selec_delta_v_;


    ///// for using qp oases////


    alpha_x_ = 1.0; gamma_x_ = 0.0002; // alpha 1.0 beta 1.0 gamma 0.0002 for x :::: for y
    alpha_y_ = 1.0; gamma_y_ = 0.000001;//001; // :::: for y alpha 1.0 beta 0.000001 gamma 0.000001
    Qx_.resize(N,N);    Qx_.setZero();
    Qy_.resize(N,N);    Qy_.setZero();

    Qx_ = alpha_x_*pu_t_pu + beta_x_*Q_v + gamma_x_ * Iden_nl;
    Qy_ = alpha_y_*pu_t_pu + beta_y_*Q_v + gamma_y_ * Iden_nl;

//    for(int i=0;i<N;i++){
//        for(int j=0;j<3;j++)
//            file[27]<<Av_(i,j)<<"\t";
//        file[27]<<endl;
//    }
//    file[27]<<endl;

    //////////////////////// for using velocity variance /////////////////
    Av_variance_.resize(N,3);
    bv_variance_.resize(N,N);

    Eigen::MatrixXd selec_variance, Ones_nl;
    selec_variance.resize(N,N); Ones_nl.resize(N,N);
    Ones_nl.setOnes();
    selec_variance = Iden_nl-Ones_nl/N;
    Av_variance_ = selec_variance*Av_;
    bv_variance_ = selec_variance*bv_;

    Eigen::MatrixXd b_var_t_b_var;
    b_var_t_b_var.resize(N,N);
    b_var_t_b_var = bv_variance_.transpose()*bv_variance_;

    Qx_variance_.resize(N,N);
    Qx_variance_inverse_.resize(N,N);

    Qx_variance_ = alpha_x_*pu_t_pu + beta_x_*b_var_t_b_var/N +gamma_x_ *Iden_nl;
    Qx_variance_inverse_ = Qx_variance_.inverse();

    Qy_variance_.resize(N,N);
    Qy_variance_inverse_.resize(N,N);

    Qy_variance_ = alpha_y_*pu_t_pu + beta_y_*b_var_t_b_var/N +gamma_y_ *Iden_nl;
    Qy_variance_inverse_ = Qy_variance_.inverse();

}
void WalkingController::SupportfootComUpdate(){
    if (walking_tick_ == t_start_+t_total_-1 && current_step_num_ != total_step_num_-1)
    {
      Eigen::Vector3d com_pos_prev;
      Eigen::Vector3d com_pos;
      Eigen::Vector3d com_vel_prev;
      Eigen::Vector3d com_vel;
      Eigen::Vector3d com_acc_prev;
      Eigen::Vector3d com_acc;

      Eigen::Matrix3d temp_rot;
      Eigen::Vector3d temp_pos;

      temp_rot = DyrosMath::rotateWithZ(-foot_step_support_frame_(current_step_num_,5));
      for(int i=0; i<3; i++)
        temp_pos(i) = foot_step_support_frame_(current_step_num_,i);

      //file[26]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;

      com_pos_prev(0) = x_p1_(0);
      com_pos_prev(1) = y_p1_(0);
      com_pos = temp_rot*(com_pos_prev - temp_pos);

      com_vel_prev(0) = x_p1_(1);
      com_vel_prev(1) = y_p1_(1);
      com_vel_prev(2) = 0.0;
      com_vel = temp_rot*com_vel_prev;

      com_acc_prev(0) = x_p1_(2);
      com_acc_prev(1) = y_p1_(2);
      com_acc_prev(2) = 0.0;
      com_acc = temp_rot*com_acc_prev;

      x_p1_(0) = com_pos(0);
      x_p1_(1) = com_vel(0);
      x_p1_(2) = com_acc(0);

      y_p1_(0) = com_pos(1);
      y_p1_(1) = com_vel(1);
      y_p1_(2) = com_acc(1);

      //file[27]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;
    }
}
void WalkingController::GetSupportPolygon(Eigen::MatrixXd& sp_x, Eigen::MatrixXd& sp_y){

    unsigned int n_size;

    unsigned int step_number =3;


    if(current_step_num_ >= total_step_num_ - step_number)
      n_size = (t_last_-t_start_+1)*(total_step_num_-current_step_num_)+20*hz_;
    else
      n_size = (t_last_-t_start_+1)*(step_number);
    if(current_step_num_ == 0)
      n_size = n_size + t_temp_+1;


    sp_x.resize(n_size,2);    sp_y.resize(n_size,2);
    sp_x.setZero();    sp_y.setZero();

    Eigen::MatrixXd tempx, tempy;

    unsigned int index =0;
    if(current_step_num_ ==0){
        for(int i=0;i<t_temp_;i++){
            if(i<=0/5*hz_){
                sp_x(i,1) = com_support_init_(0) + com_offset_(0);
                sp_x(i,0) = 0.0;

                sp_y(i,0) = com_support_init_(1)+com_offset_(1);
                sp_y(i,1) = com_support_init_(1)+com_offset_(1);
            }
            else if(i<1.5*hz_){
                double delx = i-0.5*hz_;
                sp_x(i,1) = com_support_init_(0) + com_offset_(0) - delx*(com_support_init_(0) + com_offset_(0))/(1.0*hz_);
                sp_x(i,0) = 0.0;

                sp_y(i,0) = com_support_init_(1)+com_offset_(1);
                sp_y(i,1) = com_support_init_(1)+com_offset_(1);
            }
            else {
                sp_x(i,0) = 0.0;
                sp_x(i,1) = 0.0;

                sp_y(i,0) = com_support_init_(1)+com_offset_(1);
                sp_y(i,1) = com_support_init_(1)+com_offset_(1);
            }
            index ++;
        }
    }

    if(current_step_num_ >=total_step_num_-step_number){
        for(unsigned int i=current_step_num_;i<total_step_num_;i++){
            onestepSupportPolygon(i,tempx,tempy);
            for(unsigned int j=0;j<t_total_;j++){
                sp_x(index+j,0) = tempx(j,0);
                sp_x(index+j,1) = tempx(j,1);

                sp_y(index+j,0) = tempy(j,0);
                sp_y(index+j,1) = tempy(j,1);
            }
            index = index+t_total_;
        }
        for(unsigned int j=0;j<20*hz_;j++){
            sp_x(index+j,0) = sp_x(index-1,0);
            sp_x(index+j,1) = sp_x(index-1,1);

            sp_y(index+j,0) = sp_y(index-1,0);
            sp_y(index+j,1) = sp_y(index-1,1);
        }
        index = index+20*hz_;
    }
    else{
        for(unsigned int i=current_step_num_;i<current_step_num_+ step_number;i++){
            onestepSupportPolygon(i,tempx,tempy);
            for(unsigned int j=0;j<t_total_;j++){
                sp_x(index+j,0) = tempx(j,0);
                sp_x(index+j,1) = tempx(j,1);

                sp_y(index+j,0) = tempy(j,0);
                sp_y(index+j,1) = tempy(j,1);
            }
            index = index+t_total_;
        }
    }
    if(walking_tick_==t_start_ || walking_tick_ ==0){
        if(current_step_num_ ==0){
            for(int i=0;i<n_size;i++)
                file[18]<<walking_tick_<<"\t"<<current_step_num_<<"\t"<<sp_x(i,0)<<"\t"<<sp_x(i,1)<<"\t"<<sp_y(i,0)<<"\t"<<sp_y(i,1)<<endl;
        }
        else if(current_step_num_ ==1){
            for(int i=0;i<n_size;i++)
                file[19]<<walking_tick_<<"\t"<<current_step_num_<<"\t"<<sp_x(i,0)<<"\t"<<sp_x(i,1)<<"\t"<<sp_y(i,0)<<"\t"<<sp_y(i,1)<<endl;
        }
        else if(current_step_num_ ==2){
            for(int i=0;i<n_size;i++)
                file[20]<<walking_tick_<<"\t"<<current_step_num_<<"\t"<<sp_x(i,0)<<"\t"<<sp_x(i,1)<<"\t"<<sp_y(i,0)<<"\t"<<sp_y(i,1)<<endl;
        }
        else if(current_step_num_ ==3){
            for(int i=0;i<n_size;i++)
                file[21]<<walking_tick_<<"\t"<<current_step_num_<<"\t"<<sp_x(i,0)<<"\t"<<sp_x(i,1)<<"\t"<<sp_y(i,0)<<"\t"<<sp_y(i,1)<<endl;
        }

    }
}
void WalkingController::onestepSupportPolygon(unsigned int current_step_number, Eigen::MatrixXd& tempx, Eigen::MatrixXd& tempy){
    tempx.resize(t_total_,2);
    tempy.resize(t_total_,2);

    double x_length, y_length;
    x_length = 0.15; y_length = 0.1;

    if(current_step_number ==0){
        for(int i=0;i<t_total_;i++){
            if( i < t_rest_init_){
                tempx(i,0) = rfoot_support_init_.translation()(0) - x_length;
                tempx(i,1) = lfoot_support_init_.translation()(0) + x_length;;

                tempy(i,0) = rfoot_support_init_.translation()(1) -y_length;
                tempy(i,1) = lfoot_support_init_.translation()(1)+y_length;
            }
            else if (i>= t_rest_init_ && i <t_rest_init_+t_double1_) {
                tempx(i,0) = supportfoot_support_init_offset_(0) -x_length;;
                tempx(i,1) = supportfoot_support_init_offset_(0)+x_length;;

                tempy(i,0) = rfoot_support_init_.translation()(1)-y_length;
                tempy(i,1) = lfoot_support_init_.translation()(1)+y_length;
            }
            else if (i>= t_rest_init_+t_double1_ && i< t_total_-t_rest_last_-t_double2_) {
                tempx(i,0) = supportfoot_support_init_offset_(0)-x_length;;
                tempx(i,1) = supportfoot_support_init_offset_(0)+x_length;;

//                tempy(i,0) = supportfoot_support_init_offset_(1)-y_length;
//                tempy(i,1) = supportfoot_support_init_offset_(1)+y_length;
                tempy(i,0) = lfoot_support_init_.translation()(1)-y_length;
                tempy(i,1) = lfoot_support_init_.translation()(1)+y_length;
            }
            else{
                tempx(i,0) = supportfoot_support_init_offset_(0)-x_length;
                tempx(i,1) = foot_step_support_frame_(current_step_number,0) + x_length;
               // tempx(i,1) = (supportfoot_support_init_offset_(0) + foot_step_support_frame_(current_step_number,0))/2.0;

                //tempx(i,0) = (supportfoot_support_init_offset_(1) + foot_step_support_frame_(current_step_number,1))/2.0;
                tempy(i,0) = foot_step_support_frame_(current_step_number,1) - y_length;
                tempy(i,1) = lfoot_support_init_.translation()(1)+y_length;//supportfoot_support_init_offset_(1)+y_length;
            }
        }
    }
    else if(current_step_number==1){
        for(int i=0;i<t_total_;i++){
            if(i<t_rest_init_ + t_double1_){
                //tempx(i,0) = (supportfoot_support_init_(0)+foot_step_support_frame_(current_step_number-1,0))/2.0;
                tempx(i,0) = supportfoot_support_init_offset_(0) - x_length;
                tempx(i,1) = foot_step_support_frame_offset_(current_step_number-1,0) + x_length;

                if(foot_step_support_frame_(current_step_number-1,6)==0){//left foot swing , right foot support)
                    //tempy(i,1) = (supportfoot_support_init_offset_(1) + foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,1) = supportfoot_support_init_offset_(1) + y_length;
                    tempy(i,0) = foot_step_support_frame_offset_(current_step_number-1,1)-y_length;
                }
                else{
                    //tempy(i,0) = (supportfoot_support_init_offset_(1) + foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,0) = supportfoot_support_init_offset_(1) - y_length;
                    tempy(i,1) = foot_step_support_frame_offset_(current_step_number-1,1)+y_length;
                }
            }
            else if(i>= t_rest_init_ + t_double1_ && i<t_total_-t_rest_last_-t_double2_){

                tempx(i,0) = foot_step_support_frame_offset_(current_step_number-1,0)-x_length;
                tempx(i,1) = foot_step_support_frame_offset_(current_step_number-1,0)+x_length;

                tempy(i,0) = foot_step_support_frame_offset_(current_step_number-1,1)-y_length;
                tempy(i,1) = foot_step_support_frame_offset_(current_step_number-1,1)+y_length;

            }
            else {
                tempx(i,0) = foot_step_support_frame_offset_(current_step_number-1,0)-x_length;
                //tempx(i,1) = (foot_step_support_frame_(current_step_number-1,0)+foot_step_support_frame_(current_step_number,0))/2.0;
                tempx(i,1) = foot_step_support_frame_(current_step_number,0) + x_length;

                if(foot_step_support_frame_(current_step_number-1,6)==0){//left foot swing , right foot support)
                    tempy(i,0) = foot_step_support_frame_offset_(current_step_number-1,1) - y_length;
                    //tempy(i,1) = (foot_step_support_frame_(current_step_number,1)+foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,1) = foot_step_support_frame_(current_step_number,1) +y_length;
                }
                else{//right foot swing left foot support
                    //tempy(i,0) = (foot_step_support_frame_(current_step_number,1)+foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,0) = foot_step_support_frame_(current_step_number,1) - y_length;
                    tempy(i,1) = foot_step_support_frame_offset_(current_step_number-1,1) + y_length;
                }
            }
        }
    } // end of else if(current_step_number ==1)
    else{
        for(int i=0;i<t_total_;i++){
            if(i<t_rest_init_ + t_double1_){
                //tempx(i,0) = (foot_step_support_frame_(current_step_number-2,0)+foot_step_support_frame_(current_step_number-1,0))/2.0;
                tempx(i,0) = foot_step_support_frame_(current_step_number-2,0) - x_length;
                tempx(i,1) = foot_step_support_frame_offset_(current_step_number-1,0) + x_length;

                if(foot_step_support_frame_(current_step_number-1,6)==0){//left foot swing , right foot support)
                    tempy(i,1) = foot_step_support_frame_(current_step_number-2,1)+y_length;
                    tempy(i,0) = foot_step_support_frame_offset_(current_step_number-1,1)-y_length;
                }
                else{
                    //tempy(i,0) = (supportfoot_support_init_offset_(1) + foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,0) = foot_step_support_frame_(current_step_number-2,1) - y_length;
                    tempy(i,1) = foot_step_support_frame_offset_(current_step_number-1,1)+y_length;
                }
            }
            else if(i>= t_rest_init_ + t_double1_ && i<t_total_-t_rest_last_-t_double2_){

                tempx(i,0) = foot_step_support_frame_offset_(current_step_number-1,0)-x_length;
                tempx(i,1) = foot_step_support_frame_offset_(current_step_number-1,0)+x_length;

                tempy(i,0) = foot_step_support_frame_offset_(current_step_number-1,1)-y_length;
                tempy(i,1) = foot_step_support_frame_offset_(current_step_number-1,1)+y_length;

            }
            else {
                tempx(i,0) = foot_step_support_frame_offset_(current_step_number-1,0)-x_length;
                //tempx(i,1) = (foot_step_support_frame_(current_step_number-1,0)+foot_step_support_frame_(current_step_number,0))/2.0;
                tempx(i,1) = foot_step_support_frame_(current_step_number,0) + x_length;

                if(foot_step_support_frame_(current_step_number-1,6)==0){//left foot swing , right foot support)
                    tempy(i,0) = foot_step_support_frame_offset_(current_step_number-1,1) - y_length;
                    //tempy(i,1) = (foot_step_support_frame_(current_step_number,1)+foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,1) = foot_step_support_frame_(current_step_number,1) + y_length;
                }
                else{//right foot swing left foot support
                    //tempy(i,0) = (foot_step_support_frame_(current_step_number,1)+foot_step_support_frame_(current_step_number-1,1))/2.0;
                    tempy(i,0) = foot_step_support_frame_(current_step_number,1) -  y_length;
                    tempy(i,1) = foot_step_support_frame_offset_(current_step_number-1,1) + y_length;
                }
            }
        }
    }// end of else
}
void WalkingController::Obtain_com_pattern(ifstream& input_x,ifstream& input_y, ifstream& foot_input, Eigen::MatrixXd& com_x,Eigen::MatrixXd& com_y, Eigen::MatrixXd& input_foot ){
    com_x.resize(2410,9);
    com_x.setZero();

    com_y.resize(2545,7);
    com_y.setZero();
//    com_x.resize(2801,9);
//    com_x.setZero();

    input_foot.resize(2801,13);
    input_foot.setZero();

//    int cols, rows;

//    int chk =0;
//    int i=0, j=0, mj=0;

//    FILE* stream;
//    stream = fopen(input, "r");
//    while(chk != EOF){
//        ++i;
//        j=0;
//        chk=0;
//        while (chk!= '\n' && chk != EOF){
//            ++j;
//            chk = fgetc(input);
//            fseek(input,-1,SEEK_CUR);
//        }
//        if(mj<j)
//            mj=j;
//    }

    for(int i=0;i<2410;i++){
        input_x >> com_x(i,0) >> com_x(i,1) >> com_x(i,2)>> com_x(i,3) >> com_x(i,4) >> com_x(i,5)>>com_x(i,6)>>com_x(i,7) >> com_x(i,8);// >> com_x(i,9) >> com_x(i,10)>> com_x(i,11) >> com_x(i,12) >> com_x(i,13)>>com_x(i,14);
        //file[17]<<com_x(i,0)<<"\t"<<com_x(i,1)<<"\t"<<com_x(i,2)<<com_x(i,3)<<"\t"<<com_x(i,4)<<"\t"<<com_x(i,5)<<com_x(i,6)<<"\t"<<com_x(i,7)<<"\t"<<com_x(i,8)<<endl;
        //file[16]<<com_x(i,0)<<"\t"<<com_x(i,1)<<"\t"<<com_x(i,2)<<"\t"<<com_x(i,3)<<"\t"<<com_x(i,4)<<"\t"<<com_x(i,5)<<"\t"<<com_x(i,6)<<"\t"<<com_x(i,7)<<"\t"<<com_x(i,8)<<endl;
    }


    for(int i=0;i<2545;i++){
        input_y >> com_y(i,0) >> com_y(i,1) >> com_y(i,2)>> com_y(i,3) >> com_y(i,4) >> com_y(i,5)>>com_y(i,6);//com_y(i,7) >> com_y(i,8) >> com_y(i,9) >> com_y(i,10)>> com_y(i,11) >> com_y(i,12) >> com_y(i,13)>>com_y(i,14);

    }

//    for(int i=0;i<2801;i++){
//        input >> com_x(i,0) >> com_x(i,1) >> com_x(i,2)>> com_x(i,3) >> com_x(i,4) >> com_x(i,5)>>com_x(i,6)>>com_x(i,7) >> com_x(i,8);
//        file[17]<<com_x(i,0)<<"\t"<<com_x(i,1)<<"\t"<<com_x(i,2)<<endl;
//    }


    for(int i=0;i<2801;i++){
        foot_input >> input_foot(i,0) >> input_foot(i,1) >> input_foot(i,2)>> input_foot(i,3) >> input_foot(i,4) >> input_foot(i,5)>>input_foot(i,6)>>input_foot(i,7) >> input_foot(i,8) >> input_foot(i,9) >> input_foot(i,10)>> input_foot(i,11) >> input_foot(i,12);
        //file[17]<<input_foot(i,0)<<"\t"<<input_foot(i,1)<<"\t"<<input_foot(i,2)<<endl;
    }
}
void WalkingController::settingParameter(){


    Eigen::Matrix<double, 6, 7> jacobian_A;
    jacobian_A.setZero();
    jacobian_A = current_leg_waist_l_jacobian_;


//    for(int i= 0;i<6;i++){
//        for(int j=0;j<6;j++){
//            params.A[i + j *6] = current_leg_jacobian_r_(i,j);
//        }
//    }
//    for(int i=0;i<12;i++){
//        for(int j=0;j<12;j++){
//            params.A[i + j*12] = jacobian_A(i,j);
//        }
//    }

//    for(int i=0;i<6;i++){
//        for(int j=0;j<7;j++){
//            params.A[i + j*6] = jacobian_A(i,j);
//        }
//    }

    Eigen::VectorXd y_input(6);
    Eigen::Matrix6d Kp;
    Kp.setIdentity();
    Kp *= 200.0;

    y_input = Kp*lp_;
//    y_input(5) *= 0.5;
//    y_input(11) *= 0.5;

//    for(int i=0;i<6;i++){
//    //    params.Y[i] = rfoot_trajectory_float_.translation()(i) ;
//          params.Y[i] = y_input(i) ;
//    }

//    Eigen::Matrix7d iden;
//    iden.setIdentity();

//    for(int i=0;i<7;i++){
//        for(int j=0;j<7;j++){
//            params.Q[i+ 7*j] = iden(i,j);
//        }
//    }



}
//void WalkingController::qp1(){
//    if(walking_tick_ ==0 )
//        cout<<"qp 1 test "<<endl;

//    int NL = 100;
//    double dt = 1.0/hz_;

//    Eigen::VectorXd p_ref;
//    p_ref.resize(NL);
//    double start_time;
//    if(current_step_num_ == 0)
//      start_time = 0;
//    else
//      start_time = t_start_;

//    for(int i=0;i<NL;i++)
//        p_ref(i) = ref_zmp_(walking_tick_ - start_time + i,0);


//    Eigen::Matrix3d a;
//    a.setIdentity();
//    a(0,1) = dt; a(0,2) = pow(dt,2)/2.0;
//    a(1,2) = dt;

//    Eigen::Matrix<double, 3, 1> b;
//    b(0,0) = pow(dt,3)/6.0; b(1,0) = pow(dt,2)/2.0; b(2,0) = dt;

//    //Eigen::Matrix3d::Identity()

//    Eigen::Matrix<double, 1,4> c;
//    c(0,0) = 0.0; c(0,1) = 1; c(0,2) = 0; c(0,3) = -zc_/GRAVITY;

//    Eigen::MatrixXd A_temp;
//    A_temp.resize(3*(NL-1),4*NL);
//    A_temp.setZero();
//    A_temp.block<3,1>(0,0) = -b;
//    A_temp.block<3,3>(0,1) = a+Eigen::Matrix3d::Identity();
//    A_temp.block<3,1>(0,4) = b;
//    A_temp.block<3,3>(0,5) = -Eigen::Matrix3d::Identity();

//    for(int i=1;i<NL-1;i++){
//        A_temp.block<3,3>(3*i,4*(i-1)+1) = -a;
//        A_temp.block<3,1>(3*i,4*i) = -b;
//        A_temp.block<3,3>(3*i,4*i+1) = a+Eigen::Matrix3d::Identity();
//        A_temp.block<3,1>(3*i,4*(i+1)) = b;
//        A_temp.block<3,3>(3*i,4*(i+1)+1) = -Eigen::Matrix3d::Identity();
//    }



////    if(walking_tick_ == 0){
////        cout<<"saving data : "<<endl;
////        for(int i=0;i<3*(NL-1);i++){
////            for(int j=0;j<4*NL;j++){
////                file[16]<<A_temp(i,j)<<"\t";
////            }
////            file[16]<<endl;
////        }
////    }

//    Eigen::MatrixXd c_temp;
//    c_temp.resize(NL,4*NL);

//    for(int i=0;i<NL;i++){
//        c_temp.block<1,4>(i,4*i) = c;
//    }

//    Eigen::Matrix<double, 1, 8> s;
//    s.setZero();
//    s(0,0) = -1.0; s(0,4) = 1.0;

//    Eigen::MatrixXd Selec_s;
//    Selec_s.resize(NL,4*NL);
//    Selec_s(0,0) = 1.0;
//    for(int i=1;i<NL;i++){
//        Selec_s.block<1,8>(i,4*(i-1)) = s;
//    }

////    if(walking_tick_ == 0){
////        cout<<"saving data : "<<endl;
////        for(int i=0;i<NL;i++){
////            for(int j=0;j<4*NL;j++){
////                file[16]<<Selec_s(i,j)<<"\t";
////            }
////            file[16]<<endl;
////        }
////    }

//    double r = 0.0000001;
//    Eigen::MatrixXd h_temp;
//    h_temp.resize(4*NL,4*NL);

//    Eigen::MatrixXd Q;
//    Q.resize(4*NL,4*NL);
//    Q.setIdentity();
//    h_temp = c_temp.transpose()*Q*c_temp + Selec_s.transpose() *r*Selec_s;


//    if(walking_tick_ ==0){

//    }

//    int FNL = 4*NL, NC = 3*(NL-1);
//    Eigen::EigenSolver<Eigen::MatrixXd>::EigenvectorsType z;


//    z = h_temp.eigenvalues();

//    Eigen::VectorXd z_real, z_img;

//    z_real = z.real();
//    z_img = z.imag();


//    if(walking_tick_ == 0){

//    }
//    Eigen::MatrixXd g_temp;
//    g_temp.resize(4*NL,1);
//    g_temp = -c.transpose()*p_ref;

//    Eigen::Vector3d init_x;
//    init_x.setZero();
//    if(walking_tick_ ==0){
//        init_x(0) = com_support_init_(0);
//    }
//    else {
//        init_x = x_1_;
//    }



//    Eigen::VectorXd b_temp;
//    b_temp.resize(NC);
//    b_temp.setZero();
//    b_temp.segment<3>(0) = a*init_x;


//    real_t H[FNL*FNL], g[FNL],A[NC*FNL], bA[NC],lb[FNL],ub[FNL];

//    for(int i=0;i<FNL;i++){
//        for(int j=0;j<FNL;j++){
//            H[j*FNL+i] = h_temp(i,j);
//        }
//        g[i] = g_temp(i,0);
//    }

//    for(int i=0;i<NC;i++){
//        for(int j=0;j<FNL;j++){
//            A[j*NC+i] = A_temp(i,j);
//        }
//        bA[i] = b_temp(i);
//    }

//    //SymSparseMat
//    real_t xOpt[FNL];
//    QProblem example(FNL,NC);
//    //QProblem example(FNL,NC,HST_SEMIDEF);
//    //SQProblem example(FNL,NC,HST_SEMIDEF);

//    Options myop;
//    myop.printLevel = PL_NONE;
//    example.setOptions(myop);

//    int_t nWSR = 1000;

//    for(int i=0;i<FNL;i++){
//        lb[i] = -100000000000;
//        ub[i] = -100000000000;
//    }

////    if(walking_tick_ ==0){
////        for(int i=0;i<NC;i++){
////            for(int j=0;j<FNL;j++){
////              file[18]<<A_temp(i,j)<<"\t";
////            }
////            file[18]<<endl;
////            file[19]<<b_temp(i,0)<<endl;
////        }
////        for(int i=0; i<FNL;i++){
////            file[17]<<g_temp(i,0)<<endl;
////            for(int j=0;j<FNL;j++){
////                file[16]<<h_temp(i,j)<<"\t";
////            }
////            file[16]<<endl;
////        }
////        for(int i=0;i<NL;i++)
////            file[20]<<p_ref(i)<<endl;

////        for(int i=0;i<NL;i++){
////            for(int j=0;j<4*NL;j++){
////                file[22]<<c_temp(i,j)<<"\t";
////                file[23]<<Selec_s(i,j)<<"\t";
////            }
////            file[22]<<endl;
////            file[23]<<endl;
////        }
////        for(int i=0;i<FNL;i++){
////            file[21]<<z_real(i)<<"\t"<<z_img(i)<<endl;
////        }

////    }
//    if(walking_tick_ == 0)
//        example.init(H,g,A,lb,ub,bA,bA,nWSR,0);

//    example.hotstart(g,lb,ub,bA,bA,nWSR,0);

//    example.getPrimalSolution(xOpt);

////    int_t getSimpleStatus(returnValue returnvalue);
////    cout<<"return value : "<<example.getStatus()<<endl;

//    x_1_ = a*init_x + b*xOpt[0];

////    if(walking_tick_ ==0 ){
////        for(int i=0;i<NL;i++){
////            file[16]<<xOpt[4*i+0]<<"\t"<<xOpt[4*i+1]<<"\t"<<xOpt[4*i+2]<<"\t"<<xOpt[4*i+3]<<"\t"<<endl;
////        }
////    }


//    file[15]<<walking_tick_<<"\t"<<xOpt[0]<<"\t"<<xOpt[1]<<"\t"<<xOpt[2]<<"\t"<<xOpt[3]<<"\t"<<xOpt[4]<<"\t"<<xOpt[5]<<"\t"<<xOpt[6]<<"\t"<<xOpt[7]
//           <<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;


//}
//void WalkingController::previewQP(){
//    if(walking_tick_ ==0)
//        cout<<"preview with QP solver and t_start time : "<<t_start_ <<endl;

//    int NL = 100;
//    NL = 320;
//    Eigen::Matrix3d a;
//    double dt = 1.0/hz_;

//    a.setZero();
//    a(0,0) = 1.0;    a(0,1) = dt;    a(0,2) = pow(dt,2)/2.0;
//    a(1,1) = 1.0;    a(1,2) = dt;
//    a(2,2) = 1.0;

//    Eigen::Matrix<double, 3,1> b;
//    b(0) = pow(dt,3)/6.0;
//    b(1) = pow(dt,2)/2.0;
//    b(2) = dt;

//    Eigen::Matrix<double, 1,4> c;
//    c.setZero();
//    c(1) = 1.0; c(3) = -zc_/GRAVITY;

//    Eigen::Matrix3d Iden;
//    Iden.setIdentity();

//    int FNL = 4*NL;

//    Eigen::MatrixXd A_temp;
//    A_temp.resize(FNL,FNL);
//    A_temp.setZero();
//    A_temp.block<3,1>(1,0) = b;
//    A_temp.block<3,3>(1,1) = -Iden;


//    for(int i=1;i<NL; i++){
//        A_temp.block<3,3>(4*i+1,4*i-3) = a;
//        A_temp.block<3,1>(4*i+1,4*i) = b;
//        A_temp.block<3,3>(4*i+1,4*i+1) = -Iden;
//    }

//    Eigen::Vector3d x_0;
//    x_0.setZero();

//    if(walking_tick_ == 0){
//        x_0(0)  = com_support_current_(0);
//        cout<<"support init at cnt 0 : "<<com_support_current_(0)<<endl;
//    }

//    else if(walking_tick_ == t_start_){
//        x_0(0)  = com_support_current_(0);
//    }
//    else{
//        x_0 = x_1_;// x_1_ is i-1 tick solution of x
//    }

////    else {
////        x_0 = x_1_;
////    }




//    Eigen::VectorXd b_temp;
//    b_temp.resize(FNL);
//    b_temp.setZero();
//    Eigen::Vector3d temp;
//    temp = a*x_0;
//    b_temp.segment<3>(1) =-temp;// -a*x_0;

//    if(walking_tick_ ==0){
//        cout<<"b vector ; "<<b_temp(0)<<", "<<b_temp(1)<<", "<<b_temp(2)<<", "<<b_temp(3)<<endl;
//    }


//    Eigen::Vector4d s;
//    s.setZero();
//    s(0) = 1.0;

////    Eigen::Matrix<double, 1, 8> s;
////    s.setZero();
////    s(0) = -1.0; s(4) = 1.0;


//    Eigen::MatrixXd Selec_M;
//    Selec_M.resize(NL,FNL);
//    Selec_M.setZero();
//    //Selec_M(0,0) = 1.0;
//    for(int i=0;i<NL;i++)
//        Selec_M.block<1,4>(i,4*i) = s;
//        //Selec_M.block<1,8>(i,4*(i-1)) = s;

////    if(walking_tick_ == 0){
////        cout<<"saving data : "<<endl;
////        for(int i=0;i<4*NL;i++){
////            for(int j=0;j<4*NL;j++){
////                file[16]<<Selec_M(i,j)<<"\t";
////            }
////            file[16]<<endl;
////        }
////    }

//    Eigen::MatrixXd C_temp;
//    C_temp.resize(NL,FNL);

//    for(int i=0;i<NL;i++)
//         C_temp.block<1,4>(i,4*i) = c;

//    Eigen::MatrixXd Q;
//    Q.resize(NL,NL);
//    Q.setIdentity();

//    Eigen::MatrixXd H_temp;
//    H_temp.resize(FNL,FNL);

//    double r = 0.0000001;
//    H_temp  = 100*C_temp.transpose()*C_temp;
//    H_temp += r*Selec_M.transpose()*Selec_M;


//    Eigen::VectorXd p_ref;
//    p_ref.resize(NL);
//    for(int i=0;i<NL;i++)
//        p_ref(i) = ref_zmp_(i,0);


////    if(walking_tick_ == 0){
////        file[16]<<walking_tick_;
////        for(int i=0;i<NL;i++)
////          file[16]<<"\t"<<p_ref(i);

////        file[16]<<endl;
////    }

//    Eigen::MatrixXd g_temp;
//    g_temp.resize(FNL,1);

//    g_temp = -C_temp.transpose()*p_ref;


//    real_t H[FNL*FNL], g[FNL],A[FNL*FNL],B[FNL], lb[FNL],ub[FNL];

//    for(int i=0;i<FNL;i++){
//        for(int j=0;j<FNL;j++){
//            H[j*FNL + i] = H_temp(i,j);
//            A[j*FNL +i] = A_temp(i,j);
//        }
//        g[i] = g_temp(i,0);
//        B[i] = b_temp(i);
//    }

//    real_t xOpt[FNL];

//    QProblem example(FNL,FNL);

//    Options myOptions;

//    myOptions.printLevel = PL_NONE;
//    example.setOptions(myOptions);

//    int_t nWSR = 1000;

//    for(int i=0;i<FNL;i++){
//        lb[i] = -10000000;
//        ub[i] = 10000000  ;
//    }

//    if(walking_tick_ ==0)
//        example.init(H,g,A,lb,ub,B,B,nWSR);

//    example.hotstart(g,lb,ub,B,B,nWSR);
//    example.getPrimalSolution(xOpt);

////    if(walking_tick_ ==0 ){
////        for(int i=0;i<NL;i++){
////            file[16]<<xOpt[4*i+0]<<"\t"<<xOpt[4*i+1]<<"\t"<<xOpt[4*i+2]<<"\t"<<xOpt[4*i+3]<<"\t"<<endl;
////        }
////    }

////     x_1_ =  a*x_0 + b*xOpt[0];
//////    x_1_(0) = xOpt[1];
//////    x_1_(1) = xOpt[2];
//////    x_1_(2) = xOpt[3];

////    file[15]<<walking_tick_<<"\t"<<xOpt[0]<<"\t"<<xOpt[1]<<"\t"<<xOpt[2]<<"\t"<<xOpt[3]<<"\t"<<xOpt[4]<<"\t"<<xOpt[5]<<"\t"<<xOpt[6]<<"\t"<<xOpt[7]
////           <<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;
//    //file[15]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;//<<"\t"<<x_1_(3)<<"\t"<<sol_x(0)<<"\t"<<sol_x(1)<<"\t"<<sol_x(2)<<"\t"<<sol_x(3)
////    if(walking_tick_ == 0){
////        file[15]<<walking_tick_;
////        for(int i=0;i<14;i++)
////            file[15]<<"\t"<<xOpt[4*i+1];
////        file[15]<<endl;
////    }

//}
//void WalkingController::MPCwQP(){
//    if(walking_tick_ ==0)
//        cout<<"sibalsibal"<<endl;
//////    int zmp_size;
//////    zmp_size = ref_zmp_.col(1).size();

//////    Eigen::VectorXd px_ref, py_ref;
//////    px_ref.resize(zmp_size);
//////    py_ref.resize(zmp_size);

//////    px_ref = ref_zmp_.col(0);
//////    py_ref = ref_zmp_.col(1);

////      cout<<"b"<<endl;
//    int NL = 16*hz_/10;
//    //NL = 320;

//    NL = 50;
//    Eigen::Matrix4d a;
//    Eigen::Matrix<double, 1,3>c;

//    double dt =1.0/hz_;

//    a.setIdentity();
//    a(0,1) = dt; a(0,2) = 0.5*pow(dt,2); a(0,3) = pow(dt,3)/6;
//    a(1,2) = dt; a(1,3) = pow(dt,2)/2;
//    a(2,3) = dt; a(3,3) = 0.0;

//    c(0,0) = 1; c(0,1) = 0; c(0,2) = -zc_/GRAVITY;

//////    Eigen::Vector4d b_bar;
//////    b_bar(0) = c*b;
//////    b_bar.segment(1,3) = b;

//////    Eigen::Matrix4x3d f_bar;
//////    f_bar.block<1,3>(0,0) = c*A;
//////    f_bar.block<3,3>(0,1) = A;

//////    Eigen::Matrix4d A_bar;
//////    A_bar.setZero();
//////    A_bar(0,0) = 1.0;
//////    A_bar.block<4,3>(0,1) = f_bar;

//    Eigen::MatrixXd extended_A;
//    extended_A.resize(4*NL,4*NL);
//    extended_A.setZero();
//    extended_A.block<4,4>(0,0).setIdentity();

//    for(int i=1;i<NL;i++){
//        extended_A.block<4,4>(4*i,4*(i-1)) = a;
//    }

//    Eigen::MatrixXd extended_c;
//    extended_c.resize(NL,4*NL);
//    extended_c.setZero();

//    for(int i=0;i<NL;i++){
//        extended_c.block<1,3>(i,4*i) = c;
//    }

//    Eigen::MatrixXd I_a;
//    I_a.resize(4*NL,4*NL);
//    I_a.setZero();
//    Eigen::Matrix4d iden3d;
//    iden3d.setIdentity();
//    iden3d(3,3) = 0.0;

//    for(int i=0;i<NL;i++)
//        I_a.block<4,4>(4*i,4*i) = iden3d;


//    Eigen::MatrixXd A_input;
//    A_input.resize(4*NL,4*NL);
//    A_input = extended_A - I_a; // for constraint A

//    A_input.block<3,3>(0,0).setIdentity();
//    A_input(3,3) = 0.0;

//    Eigen::VectorXd p_ref;
//    p_ref.resize(NL);

//    for(int i=0;i<NL;i++)
//        p_ref(i) = ref_zmp_(i,0);

////    if(walking_tick_ == 0){
////        cout<<"saving data : "<<endl;
////        for(int i=0;i<4*NL;i++){
////            for(int j=0;j<4*NL;j++){
////                file[16]<<A_input(i,j)<<"\t";
////            }
////            file[16]<<endl;
////        }
////    }
//    Eigen::MatrixXd S;
//    S.resize(NL,4*NL);
//    Eigen::MatrixXd sel_vector;
//    sel_vector.resize(1,8);
//    sel_vector.setZero();
//    sel_vector(0,3) = -1; sel_vector(0,7) = 1;
//    //sel_vector(0,3) = 1.0;
//    S(0,3) = 1.0;
//    for(int i=1;i<NL-1;i++)
//        S.block<1,8>(i,4*i) = sel_vector;


//    Eigen::MatrixXd h_temp;
//    h_temp.resize(4*NL,4*NL);
//    Eigen::Matrix<double, 1,1> r;
//    r(0,0) = 0.0001;

//    h_temp = 10*extended_c.transpose()*extended_c;
//    h_temp += S.transpose()*r*S;


//    Eigen::MatrixXd g_temp;
//    g_temp.resize(4*NL,1);

//    g_temp = - extended_c.transpose()*p_ref;



//    real_t H[4*NL*4*NL], g[4*NL], A[4*NL*4*NL];

//    for(int i=0;i<4*NL;i++){
//        for(int j=0;j<4*NL;j++){
//           // cout<<"test 4"<<endl;
//            H[j*4*NL + i] = h_temp(i,j);
//           // cout<<"test 5 "<<endl;
//            A[j*4*NL + i] = A_input(i,j);
//        }
//        //cout<<"test 6"<<endl;
//        g[i] = g_temp(i,0);
//    }



//    real_t xOpt[4*NL];

//    QProblem example(4*NL,4*NL);


//    Options myOptions;
//    myOptions.printLevel= PL_NONE;
//    example.setOptions(myOptions);

//    int_t nWSR = 1000;
//    real_t lbA[4*NL], lb[4*NL], ub[4*NL];
//    for(int i=0;i<4*NL;i++){
//        lbA[i] = 0.0;
//    }
//    Eigen::Vector3d x_0;
//    x_0.setZero();

//    if(walking_tick_ ==0){
//        x_0(0) = com_support_current_(0);
//    }
//    else {
//     x_0 = x_1_;
//    }
////    if(walking_tick_ == 0){
//        //lbA[0] = com_support_current_(0);
//    lbA[0] = x_0(0);
//    lbA[1] = x_0(1);
//    lbA[2] = x_0(2);

////    }
////    else if(walking_tick_ == t_start_){
//        //lbA[0] = com_support_current_(0);
////    }
////    else{

////    }
////    lbA[0] = x_1_(0);
////    lbA[1] = x_1_(1);
////    lbA[2] = x_1_(2);


////    if(walking_tick_-zmp_start_time_==0 && current_step_num_ == 0)
////        lbA[0] = com_support_init_(0);
////    else {
////        lbA[0] = x_1_(0);
////        lbA[1] = x_1_(1);
////        lbA[2] = x_1_(2);
////        lbA[3] = x_1_(3);
////    }

//    for(int i=0;i<NL;i++){
//        lb[4*i+3] = -10000000;
//        ub[4*i+3] =  10000000;
//    }

//    //xOpt[0] = com_support_current_(0);

//    if(walking_tick_ ==0)
//        example.init(H,g,A,lb,ub,lbA,lbA,nWSR);

//    example.hotstart(g,lb,ub,lbA,lbA,nWSR);

//    example.getPrimalSolution(xOpt);


////    if(walking_tick_ == 0){
////        file[16]<<walking_tick_;
////        for(int i=0;i<NL;i++)
////          file[16]<<"\t"<<p_ref(i);

////        file[16]<<endl;
////    }
////    if(walking_tick_ ==0 ){
////        for(int i=0;i<NL;i++){
////            file[16]<<xOpt[4*i+0]<<"\t"<<xOpt[4*i+1]<<"\t"<<xOpt[4*i+2]<<"\t"<<xOpt[4*i+3]<<"\t"<<endl;
////        }
////    }
//    Eigen::Vector4d sol_x;
//    for(int i=0;i<4;i++)
//        sol_x(i) = xOpt[i];

////    x_1_ = a.block<3,3>(0,0)*x_0 + a.block<3,1>(0,3)*xOpt[3];
////    //x_1_ = a*sol_x;

//////    file[15]<<walking_tick_<<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;//"\t"<<x_1_(3)<<"\t"<<sol_x(0)<<"\t"<<sol_x(1)<<"\t"<<sol_x(2)<<"\t"<<sol_x(3)
//////           <<"\t"<<xOpt[4]<<"\t"<<xOpt[5]<<"\t"<<xOpt[6]<<"\t"<<example.getObjVal()<<endl;

////   file[15]<<walking_tick_<<"\t"<<xOpt[0]<<"\t"<<xOpt[1]<<"\t"<<xOpt[2]<<"\t"<<xOpt[3]<<"\t"<<xOpt[4]<<"\t"<<xOpt[5]<<"\t"<<xOpt[6]<<"\t"<<xOpt[7]
////          <<"\t"<<x_1_(0)<<"\t"<<x_1_(1)<<"\t"<<x_1_(2)<<endl;

////   x_1_(0) = xOpt[4];
////    x_1_(1) = xOpt[5];
////    x_1_(2) = xOpt[6];
////    printf( "\nxOpt = [ %e, %e, %e, %e, %e, %e,%e, %e, %e];  objVal = %e\n\n",
////    xOpt_[0],xOpt_[1],xOpt_[2],xOpt_[3],xOpt_[4],xOpt_[5],xOpt_[6],xOpt_[7],xOpt_[8],example.getObjVal() );
////cout<<"test 7 "<<endl;

//}
void WalkingController::zmpPattern(unsigned int current_step_number, Eigen::VectorXd& temp_px, Eigen::VectorXd& temp_py){
    if(walking_tick_ == 0)
        cout<<"zmp pattern "<<endl;

    temp_px.resize(t_total_);
    temp_py.resize(t_total_);
    temp_px.setZero();
    temp_py.setZero();

    Eigen::Matrix4d time_mat;
    Eigen::Vector4d coeff_vector;
    Eigen::Vector4d value_vector;

    double td = t_rest_init_ + t_double1_;
    double ts = (t_total_-t_rest_last_-t_double2_) - (t_rest_init_+t_double1_);
    double tf = t_total_;

    time_mat.setZero();
    time_mat.col(0).setOnes();
    for(int i=1;i<4;i++){
        time_mat(1,i) = pow(td,i);
        time_mat(2,i) = pow(ts,i);
        time_mat(3,i) = pow(tf,i);
    }
    double d= 0.5*(foot_step_(current_step_num_,0) - foot_step_(current_step_num_-1,0));

    if(current_step_number == 0){
       value_vector(0) = 0.0;
       value_vector(1) = supportfoot_support_init_offset_(0);
       value_vector(2) = supportfoot_support_init_offset_(0);
       value_vector(3) = (supportfoot_support_init_offset_(0) + foot_step_support_frame_(current_step_number,0))/2.0;
    }
    else if(current_step_number ==1){
        value_vector(0) = (foot_step_support_frame_(current_step_number-1,0)+supportfoot_support_init_(0))/2.0;
        value_vector(1) = foot_step_support_frame_offset_(current_step_number-1,0);
        value_vector(2) = foot_step_support_frame_offset_(current_step_number-1,0) +d;
        value_vector(3) = (foot_step_support_frame_(current_step_number,0)+foot_step_support_frame_(current_step_number-1,0))/2.0;
    }
    else if(current_step_number >1 && current_step_number<total_step_num_){
        value_vector(0) = (foot_step_support_frame_(current_step_number-1,0)+foot_step_support_frame_(current_step_number-2,0))/2.0;
        value_vector(1) = foot_step_support_frame_offset_(current_step_number-1,0)-d;
        value_vector(2) = foot_step_support_frame_offset_(current_step_number-1,0)+d;
        value_vector(3) =  (foot_step_support_frame_(current_step_number,0)+foot_step_support_frame_(current_step_number-1,0))/2.0;
    }
    else{
        value_vector(0) = (foot_step_support_frame_(current_step_number-1,0)+foot_step_support_frame_(current_step_number-2,0))/2.0;
        value_vector(1) = foot_step_support_frame_offset_(current_step_number-1,0);
        value_vector(2) = foot_step_support_frame_offset_(current_step_number-1,0);
        value_vector(3) = foot_step_support_frame_offset_(current_step_number-1,0);
    }


    coeff_vector = time_mat.inverse()*value_vector;

    for(int i=0;i<t_total_;i++){
        temp_px(i) = coeff_vector(0) + coeff_vector(1)*i + coeff_vector(2) * pow(i,2) + coeff_vector(3) * pow(i,3);
    }

}
void WalkingController::supportToWaistPattern(){

    waist_trajectory_support_ = pelv_trajectory_support_;
    waist_trajectory_float_ = DyrosMath::inverseIsometry3d(waist_trajectory_support_)*waist_trajectory_support_;
    lfoot_trajectory_waist_ = DyrosMath::inverseIsometry3d(waist_trajectory_support_)*lfoot_trajectory_support_;
    rfoot_trajectory_waist_ = DyrosMath::inverseIsometry3d(waist_trajectory_support_)*rfoot_trajectory_support_;
    lfoot_trajectory_euler_waist_=DyrosMath::rot2Euler(lfoot_trajectory_waist_.linear());
    rfoot_trajectory_euler_waist_=DyrosMath::rot2Euler(rfoot_trajectory_waist_.linear());

}
void WalkingController::updateInitialStatefromWaist(){
    lfoot_waist_init_ = DyrosMath::inverseIsometry3d(link_transform_[WA_LINK])*lfoot_float_init_;
    rfoot_waist_init_ = DyrosMath::inverseIsometry3d(link_transform_[WA_LINK])*rfoot_float_init_;

}
void WalkingController::getRobotStatefromWaist(){

    lfoot_waist_current_ = DyrosMath::inverseIsometry3d(link_transform_[WA_LINK])*lfoot_float_current_;
    rfoot_waist_current_ = DyrosMath::inverseIsometry3d(link_transform_[WA_LINK])*rfoot_float_current_;
    if(foot_step_(current_step_num_, 6) ==0)//rifht foot support
        supportfoot_waist_current_ = rfoot_waist_current_;
    else if(foot_step_(current_step_num_,6) ==1) // left foot support
        supportfoot_waist_current_ = lfoot_waist_current_;

    waist_support_current_ = DyrosMath::inverseIsometry3d(supportfoot_waist_current_);

    current_leg_waist_l_jacobian_.leftCols(1) = current_waist_jacobian_[0].leftCols(1);
    current_leg_waist_l_jacobian_.block<6,6>(0,1) = current_leg_jacobian_l_;

    current_leg_waist_r_jacobian_.leftCols(1) = current_waist_jacobian_[0].leftCols(1);
    current_leg_waist_r_jacobian_.block<6,6>(0,1) = current_leg_jacobian_r_;

    current_leg_waist_l_jacobian_.topRows(3) = link_transform_[WA_LINK].linear().transpose()*current_leg_waist_l_jacobian_.topRows(3);
    current_leg_waist_l_jacobian_.bottomRows(3) = link_transform_[WA_LINK].linear().transpose()*current_leg_waist_l_jacobian_.bottomRows(3);

    current_leg_waist_r_jacobian_.topRows(3) = link_transform_[WA_LINK].linear().transpose()*current_leg_waist_r_jacobian_.topRows(3);
    current_leg_waist_r_jacobian_.bottomRows(3) = link_transform_[WA_LINK].linear().transpose()*current_leg_waist_r_jacobian_.bottomRows(3);

}
void WalkingController::computeWaistJacobianCtrl(Eigen::Isometry3d waist_lleg_transform, Eigen::Isometry3d waist_rleg_transform, Eigen::Vector3d waist_lleg_transform_euler, Eigen::Vector3d waist_rleg_transform_euler,Eigen::VectorXd& desired_q_dot){

    if(walking_tick_ == 0)
        cout<<"waist jacobian ctrl "<<endl;
    Eigen::Matrix6d jacobian_temp_l, jacobian_temp_r;
    double wl, wr, w0, lambda, a;
    w0 = 0.001;
    lambda = 0.05;
    jacobian_temp_l = current_leg_waist_l_jacobian_*current_leg_waist_l_jacobian_.transpose();
    jacobian_temp_r = current_leg_waist_r_jacobian_*current_leg_waist_r_jacobian_.transpose();
    wl = sqrt(jacobian_temp_l.determinant());
    wr = sqrt(jacobian_temp_r.determinant());
    Eigen::Matrix<double, 7, 6> current_leg_waist_jacobian_l_inv, current_leg_waist_jacobian_r_inv;
    Eigen::Matrix6d j_damped;

    // inverse jacobian including waist joint
    if(wl<= w0)
    {//left jacobian including waist
        a = lambda * pow(1-wl/w0,2);
        j_damped = current_leg_waist_l_jacobian_*current_leg_waist_l_jacobian_.transpose() + a*Eigen::Matrix6d::Identity();
        j_damped = j_damped.inverse();

        cout<<"Singularity Regin of left leg : "<<wl<<endl;
        current_leg_waist_jacobian_l_inv = current_leg_waist_l_jacobian_.transpose()*j_damped;
    }
    else {
        current_leg_waist_jacobian_l_inv = current_leg_waist_l_jacobian_.transpose()*(current_leg_waist_l_jacobian_*current_leg_waist_l_jacobian_.transpose()).inverse();
    }

    if(wr<= w0)
    {//left jacobian including waist
        a = lambda * pow(1-wr/w0,2);
        j_damped = current_leg_waist_r_jacobian_*current_leg_waist_r_jacobian_.transpose() + a*Eigen::Matrix6d::Identity();
        j_damped = j_damped.inverse();

        cout<<"Singularity Regin of right leg : "<<wr<<endl;
        current_leg_waist_jacobian_r_inv = current_leg_waist_r_jacobian_.transpose()*j_damped;
    }
    else {
        current_leg_waist_jacobian_r_inv = current_leg_waist_r_jacobian_.transpose()*(current_leg_waist_r_jacobian_*current_leg_waist_r_jacobian_.transpose()).inverse();
    }

    // inverse jacobian excluding waist jacobian at waist coordinate
    jacobian_temp_l = current_leg_waist_l_jacobian_.block<6,6>(0,1)*current_leg_waist_l_jacobian_.block<6,6>(0,1).transpose();
    jacobian_temp_r = current_leg_waist_r_jacobian_.block<6,6>(0,1)*current_leg_waist_r_jacobian_.block<6,6>(0,1).transpose();
    wl = sqrt(jacobian_temp_l.determinant());
    wr = sqrt(jacobian_temp_r.determinant());
    Eigen::Matrix6d current_leg_jacobian_l_inv, current_leg_jacobian_r_inv;

    if(wl<=w0){
        a = lambda * pow(1-wl/w0,2);
        j_damped = current_leg_waist_l_jacobian_.block<6,6>(0,1)*current_leg_waist_l_jacobian_.block<6,6>(0,1).transpose() + a*Eigen::Matrix6d::Identity();
        j_damped = j_damped.inverse();

        cout<<"Singularity Regin of left leg : "<<wl<<endl;
        current_leg_jacobian_l_inv = current_leg_waist_l_jacobian_.block<6,6>(0,1).transpose()*j_damped;
    }
    else{
        current_leg_jacobian_l_inv = current_leg_waist_l_jacobian_.block<6,6>(0,1).transpose()*(current_leg_waist_l_jacobian_.block<6,6>(0,1)*current_leg_waist_l_jacobian_.block<6,6>(0,1).transpose()).inverse();
    }

    if(wr<=w0){
        a = lambda * pow(1-wr/w0,2);
        j_damped = current_leg_waist_r_jacobian_.block<6,6>(0,1)*current_leg_waist_r_jacobian_.block<6,6>(0,1).transpose() + a*Eigen::Matrix6d::Identity();
        j_damped = j_damped.inverse();

        cout<<"Singularity Regin of right leg : "<<wr<<endl;
        current_leg_jacobian_r_inv = current_leg_waist_r_jacobian_.block<6,6>(0,1).transpose()*j_damped;
    }
    else{
        current_leg_jacobian_r_inv = current_leg_waist_r_jacobian_.block<6,6>(0,1).transpose()*(current_leg_waist_r_jacobian_.block<6,6>(0,1)*current_leg_waist_r_jacobian_.block<6,6>(0,1).transpose()).inverse();
    }



//    current_leg_waist_l_jacobian_inv_ = current_leg_waist_jacobian_l_inv;
//    current_leg_waist_r_jacobian_inv_ = current_leg_waist_jacobian_r_inv;

    Eigen::Matrix6d kp;
    kp.setZero();
    kp(0,0) = 200;
    kp(1,1) = 200;
    kp(2,2) = 200;
    kp(3,3) = 200;
    kp(4,4) = 200;
    kp(5,5) = 200;


    Eigen::Vector6d lp, rp, cubic_xr, cubic_xl;
    lp.setZero(); rp.setZero(); cubic_xr.setZero(); cubic_xl.setZero();

    if(walking_tick_ ==0){
        lp.topRows(3) = (-lfoot_waist_current_.translation() + waist_lleg_transform.translation());
        rp.topRows(3) = (-rfoot_waist_current_.translation() + waist_rleg_transform.translation());
    }
    else{
        lp.topRows(3) = (-pre_lfoot_trajectory_waist_.translation() + waist_lleg_transform.translation());
        rp.topRows(3) = (-pre_rfoot_trajectory_waist_.translation() + waist_rleg_transform.translation());
    }


    cubic_xl.topRows(3) = waist_lleg_transform.translation();
    cubic_xl.bottomRows(3) = waist_lleg_transform_euler;

    cubic_xr.topRows(3) = waist_rleg_transform.translation();
    cubic_xr.bottomRows(3) = waist_rleg_transform_euler;

    Eigen::Vector3d rleg_waist_phi, lleg_waist_phi;

    Eigen::Matrix6d jacobian_check;
    jacobian_check = current_leg_waist_l_jacobian_*current_leg_waist_jacobian_l_inv;

//    if(walking_tick_ ==0){
//        cout<<"lfoot position trajectory at waist "<<endl<<waist_lleg_transform.translation()<<endl;
//        cout<<"lfoot possition trajectory at waist "<<endl<<lfoot_waist_current_.translation()<<endl;
//        cout<<"lfoot position trajectory at pelvis :"<<endl<<lfoot_trajectory_float_.translation()<<endl;
//        cout<<"lf "<<lp<<endl;
//        cout<<"lfoot position current at pelvis : "<<endl<<lfoot_float_current_.translation()<<endl;
//        cout<<"jacobian check : "<<endl<<jacobian_check<<endl;
//    }

    if(walking_tick_ == 0){
        lleg_waist_phi = DyrosMath::legGetPhi(lfoot_waist_current_,lfoot_waist_init_, cubic_xl);
        rleg_waist_phi = DyrosMath::legGetPhi(rfoot_waist_current_,rfoot_waist_init_, cubic_xr);
    }
    else{
        lleg_waist_phi = DyrosMath::legGetPhi(pre_lfoot_trajectory_waist_,lfoot_waist_init_, cubic_xl);
        rleg_waist_phi = DyrosMath::legGetPhi(pre_rfoot_trajectory_waist_,rfoot_waist_init_, cubic_xr);
    }

//    if(walking_tick_ == 0){
//        lleg_waist_phi = DyrosMath::getPhi(lfoot_waist_current_.linear(), waist_lleg_transform.linear());
//        rleg_waist_phi = DyrosMath::getPhi(rfoot_waist_current_.linear(), waist_lleg_transform.linear());
//    }
//    else{
//        lleg_waist_phi = DyrosMath::getPhi(pre_lfoot_trajectory_waist_.linear(), waist_lleg_transform.linear());
//        rleg_waist_phi = DyrosMath::getPhi(pre_rfoot_trajectory_waist_.linear(), waist_lleg_transform.linear());
//    }


    lp.bottomRows(3) = -lleg_waist_phi;
    rp.bottomRows(3) = -rleg_waist_phi;

    lp.bottomRows(3).setZero();
    rp.bottomRows(3).setZero();
    lp_ = lp;

    Eigen::Vector6d q_foot_dot;
    Eigen::Vector7d q_waist_foot_dot;

//    lp.setZero();
//    rp.setZero();
    if(foot_step_(current_step_num_,6) == 1){// left foot support
//        lp.bottomRows(3) = -lleg_waist_phi;
//        rp.bottomRows(3) = rleg_waist_phi;

        q_waist_foot_dot = current_leg_waist_jacobian_l_inv*(kp*lp);
        q_foot_dot = current_leg_jacobian_r_inv*kp*rp;

        desired_q_dot.segment(0,6) = q_waist_foot_dot.segment(1,6);
        desired_q_dot.segment(6,6) = q_foot_dot;
        desired_q_dot(12) = q_waist_foot_dot(0);

    }
    else{
//        lp.bottomRows(3) = lleg_waist_phi;
//        rp.bottomRows(3) = -rleg_waist_phi;

        q_waist_foot_dot = current_leg_waist_jacobian_r_inv*(kp*rp);
        q_foot_dot = current_leg_jacobian_l_inv*kp*lp;

        desired_q_dot.segment(0,6) = q_foot_dot;
        desired_q_dot.segment(6,6) = q_waist_foot_dot.segment(1,6);
        desired_q_dot(12) = q_waist_foot_dot(0);


    }
    Eigen::Vector6d check;
    check = current_leg_waist_l_jacobian_*q_waist_foot_dot;

    file[8]<<walking_tick_;

    for(int i=0;i<13;i++)
        file[8]<<"\t"<<desired_q_dot (i)*RAD2DEG;

    file[8]<<"\t"<<check(0)<<"\t"<<check(1)<<"\t"<<check(2)<<"\t"<<check(3)<<"\t"<<check(4)<<"\t"<<check(5);
    file[8]<<endl;





}

}




