#include "dyros_jet_controller/dyros_jet_model.h"
#include "dyros_jet_controller/walking_controller.h"
#include "cvxgen_6_8_0/cvxgen/solver.h"
#include <stdio.h>

namespace dyros_jet_controller
{

void WalkingController::JoystickWalkingPlanning(){
    if(joystick_walking_flag_ ==true)
    {
        if(joystick_planning_ == true)
        {
            JoyFootstepGoon();
        }
    }

}
void WalkingController::JoyFootstepGoon(){
   //function for joystick footstep update when left trigger on
    if(walking_tick_ == 0){
        foot_step_joy_.resize(5,7);
        foot_step_joy_support_frame_.resize(5,7);
        foot_step_joy_support_frame_offset_.resize(5,7);
        foot_step_joy_.setZero();
        foot_step_joy_support_frame_.setZero();
        foot_step_joy_support_frame_offset_.setZero();

        total_step_num_ = 5;
    }
    unsigned int number_of_footstep =5;
    int temp =-1;
    int index =0;

    double dlength = 0.1;

    if(joystick_input_(3) >0){
        if(joystick_walking_on_ == true){
            total_step_num_joy_ = current_step_num_ +3; // finish at swing foot landing position.
            joystick_walking_on_ = false; // begin stop sequence
            joystick_stop_begin_num_ = current_step_num_;
            cout<<" Joystick Walking Stop begin at "<<joystick_stop_begin_num_<<endl;
        }

    }
    else {
        if(joystick_walking_on_ == false){
            joystick_walking_on_ = true;
          // cout<<"!!!!!!!!!!!!!!!Joystick Walking restart"<<endl;
        }
    }
    Eigen::Matrix<double, 5,7> p_foot_step;
    p_foot_step.setZero();

    if(walking_tick_ ==0 || walking_tick_ == t_start_){
        if(joystick_input_(3) <= 0){ // joystick walking cmd on
            total_step_num_ = current_step_num_+3;
            if(current_step_num_ <=2){
                for(int i=0;i<number_of_footstep;i++){
                    temp *= -1;
                    foot_step_joy_(index,0) = dlength*(i+1);
                    foot_step_joy_(index,1) = -temp*0.127794;
                    foot_step_joy_(index,6) = 0.5+0.5*temp;

                    index++;
                }
            }
            else { // current step number >=3
                Eigen::MatrixXd foot_matrix_temp(2,7);
                foot_matrix_temp = foot_step_joy_.block<2,7>(1,0);
                if(foot_step_joy_(1,6) == 0){
                    temp =1;
                }
                else {
                    temp = -1;
                }

                foot_step_joy_.block<2,7>(0,0) = foot_matrix_temp;

                for(int i=2;i<number_of_footstep;i++){
                    temp *= -1;
                    foot_step_joy_(i,0) = foot_step_joy_(i-1,0) + dlength;
                    foot_step_joy_(i,1) = -temp*0.127794;
                    foot_step_joy_(i,6) = 0.5+0.5*temp;
                }
            }
        }
        else { // joystick_input(3)>0 and stop cmd on
            //foot_step_joy_.col(4) = foot_step_joy_.col(3);
            if(current_step_num_ <=2){
                foot_step_joy_(current_step_num_+1,0) = foot_step_joy_(current_step_num_,0);
                foot_step_joy_(current_step_num_+1,1) = -1*foot_step_joy_(current_step_num_,1);
                if(foot_step_joy_(current_step_num_,6) ==0)
                    foot_step_joy_(current_step_num_+1,6) =1;
                else {
                    foot_step_joy_(current_step_num_+1,6) =0;
                }


            }
            else{
                foot_step_joy_(4,0) = foot_step_joy_(3,0);
                foot_step_joy_(4,1) = -1*foot_step_joy_(3,1);
                if(foot_step_joy_(3,6) ==1)
                    foot_step_joy_(4,6) = 0;
                if(foot_step_joy_(3,6) == 0)
                    foot_step_joy_(4,6) =1;
            }


            cout<<"stop step planning"<<endl;
        }

        cout<<"step numbeer  "<<current_step_num_<<"  foot step joy: "<<endl<<foot_step_joy_<<endl;
    }
    else {
        foot_step_joy_ = foot_step_joy_;
    }


//    if(walking_tick_ ==0 || walking_tick_ == t_start_){
//        cout<<"foot step joy: "<<endl<<foot_step_joy_<<endl;
//    }
}
void WalkingController::JoyZMPtrajectory(){
    unsigned int planning_step_number  = 3;

    unsigned int norm_size = 0;

    //if(current_step_num_ >= total_step_num_ - planning_step_number)
    if(joystick_input_(3) > 0){ // stop cmd on
      norm_size = (t_last_-t_start_+1)*(total_step_num_joy_-current_step_num_)+20*hz_;
    }
    else
      norm_size = (t_last_-t_start_+1)*(planning_step_number);
    if(current_step_num_ == 0)
      norm_size = norm_size + t_temp_+1;

    JoyaddZmpOffset();
    JoyZMPGenerator(norm_size, planning_step_number);

    ref_zmp_ =ref_zmp_joy_;

    if(walking_tick_ ==0 || walking_tick_ == t_start_){
        cout<<"walking tick :"<<walking_tick_<<"step num : "<<current_step_num_<<" foot step joy support frame"<<endl<<foot_step_joy_support_frame_offset_<<endl;
    }

}
void WalkingController::JoyZMPGenerator(const unsigned int norm_size, const unsigned planning_step_num){
    ref_zmp_joy_.resize(norm_size,2);

    com_offset_.setZero();

    // planning step num is 3
    Eigen::VectorXd temp_px;
    Eigen::VectorXd temp_py;

    unsigned int index =0;


    if(current_step_num_ ==0)
    {
        if(walking_tick_ ==0)
            cout<<"com init on joyzmp at 0 : "<<com_support_init_(1)+com_offset_(1)<<endl;
      for (int i=0; i<= t_temp_; i++) //200 tick
      {          
        if(i <= 0.5*hz_)
        {
          ref_zmp_joy_(i,0) = com_support_init_(0)+com_offset_(0);
          ref_zmp_joy_(i,1) = com_support_init_(1)+com_offset_(1);
        }
        else if(i < 1.5*hz_)
        {
          double del_x = i-0.5*hz_;
          ref_zmp_joy_(i,0) = com_support_init_(0)+com_offset_(0)-del_x*(com_support_init_(0)+com_offset_(0))/(1.0*hz_);
          ref_zmp_joy_(i,1) = com_support_init_(1)+com_offset_(1);
        }
        else
        {
          ref_zmp_joy_(i,0) = 0.0;
          ref_zmp_joy_(i,1) = com_support_init_(1)+com_offset_(1);
        }
        index++;
      }
    }
    if(joystick_input_(3) > 0)// walking cmd off
    {
//        if(current_step_num_<total_step_num_joy_){
//              for(unsigned int i = current_step_num_; i<total_step_num_joy_ ; i++)
//              {
//                 // cout<<"hello3 "<<endl;
//               // zmpPattern(i,temp_px1,temp_py);
//                onestepZmp(i,temp_px,temp_py);
//               // onestepZmp_modified(i,temp_px,temp_py);

//                for (unsigned int j=0; j<t_total_; j++)
//                {
//                  ref_zmp_joy_(index+j,0) = temp_px(j);
//                  ref_zmp_joy_(index+j,1) = temp_py(j);

//                }
//                index = index+t_total_;
//              }

//              for (unsigned int j=0; j<20*hz_; j++)
//              {
//                ref_zmp_joy_(index+j,0) = ref_zmp_joy_(index-1,0);
//                ref_zmp_joy_(index+j,1) = ref_zmp_joy_(index-1,1);
//              }
//              final_ref_zmp_(0) = ref_zmp_joy_(index,0);
//              final_ref_zmp_(1) = ref_zmp_joy_(index,1);
//              index = index+20*hz_;
//        }
//        else {
//            //cout<<"hello4"<<endl;
//              for(unsigned int j=0;j<norm_size;j++){
//                ref_zmp_joy_(j,0) = final_ref_zmp_(0);
//                ref_zmp_joy_(j,1) = final_ref_zmp_(1);
//            }
//        }
        for(unsigned int i= current_step_num_; i<total_step_num_joy_;i++){
            //JoyonestepZmp(i,temp_px,temp_py);
            JoystopstepZmp(i,temp_px,temp_py);

            for (unsigned int j=0; j<t_total_; j++)
            {
              ref_zmp_joy_(index+j,0) = temp_px(j);
              ref_zmp_joy_(index+j,1) = temp_py(j);
             // ref_zmp_(index+j,0) = temp_px1(j);
            }

            index = index + t_total_;
        }

        for( unsigned int j=0;j<20*hz_;j++){
            ref_zmp_joy_(index+j,0) = ref_zmp_joy_(index-1,0);
            ref_zmp_joy_(index+j,1) = ref_zmp_joy_(index-1,1);
        }

    }
    else //joystick trigger ON --> walking sequence go on
    {
      for(unsigned int i=0; i < 3; i++)
      {
      //  zmpPattern(i,temp_px1,temp_py);
        JoyonestepZmp(i,temp_px,temp_py);
        //onestepZmp_modified(i,temp_px,temp_py);
        for (unsigned int j=0; j<t_total_; j++)
        {
          ref_zmp_joy_(index+j,0) = temp_px(j);
          ref_zmp_joy_(index+j,1) = temp_py(j);

        }
        index = index+t_total_;
       }
      } //for if(current_step_number_>!!@!@!#~~~~~~~~!
    if(walking_tick_ ==0 || walking_tick_==t_start_){
        file[10]<<walking_tick_<<"\t"<<current_step_num_;
        file[15]<<walking_tick_<<"\t"<<current_step_num_;
        for(int i=0;i<norm_size;i++){
            file[10]<<"\t"<<ref_zmp_joy_(i,1);
            file[15]<<"\t"<<ref_zmp_joy_(i,0);
        }
        file[15]<<endl;
        file[10]<<endl;
    }
}

void WalkingController::JoyfloatToSupportFootstep(){
    Eigen::Isometry3d reference;
    double step_planning_num =5;

    if(current_step_num_ == 0){
        if(foot_step_joy_(0,6) == 0) //right support
        {
          reference.translation() = rfoot_float_init_.translation();
          reference.translation()(2) = 0.0;
          reference.linear() = DyrosMath::rotateWithZ(DyrosMath::rot2Euler(rfoot_float_init_.linear())(2));
          reference.translation()(0) = 0.0;
        }
        else  //left support
        {
          reference.translation() = lfoot_float_init_.translation();
          reference.translation()(2) = 0.0;
          reference.linear() = DyrosMath::rotateWithZ(DyrosMath::rot2Euler(lfoot_float_init_.linear())(2));
          reference.translation()(0) = 0.0;
        }
    }
    else if(current_step_num_<=2){
        reference.linear() = DyrosMath::rotateWithZ(foot_step_joy_(current_step_num_-1,5));
        for(int i=0 ;i<3; i++)
          reference.translation()(i) = foot_step_joy_(current_step_num_-1,i);
    }
    else {
        reference.linear() = DyrosMath::rotateWithZ(foot_step_joy_(1,5));
        for(int i=0 ;i<3; i++)
          reference.translation()(i) = foot_step_joy_(1,i);
    }
    if(joystick_walking_on_ == false){
        double seq = current_step_num_-joystick_stop_begin_num_;
        reference.linear() = DyrosMath::rotateWithZ(foot_step_joy_(1+seq,5));
        for(int i=0 ;i<3; i++)
          reference.translation()(i) = foot_step_joy_(1+seq,i);
    }

    Eigen::Vector3d temp_local_position;
    Eigen::Vector3d temp_global_position;

    if(current_step_num_ == 0)
    {
      for(int i=0; i<step_planning_num; i++)
      {
        for(int j=0; j<3; j++)
          temp_global_position(j)  = foot_step_joy_(i,j);

        temp_local_position = reference.linear().transpose()*(temp_global_position-reference.translation());

        for(int j=0; j<3; j++)
          foot_step_joy_support_frame_(i,j) = temp_local_position(j);

        foot_step_joy_support_frame_(i,3) = foot_step_joy_(i,3);
        foot_step_joy_support_frame_(i,4) = foot_step_joy_(i,4);
        foot_step_joy_support_frame_(i,5) = foot_step_joy_(i,5) - supportfoot_float_init_(5);

      }
    }
    else
    {
      for(int i=0; i<step_planning_num; i++)
      {
        for(int j=0; j<3; j++)
          temp_global_position(j)  = foot_step_joy_(i,j);

        temp_local_position = reference.linear().transpose()*(temp_global_position-reference.translation());

        for(int j=0; j<3; j++)
          foot_step_joy_support_frame_(i,j) = temp_local_position(j);

        if(current_step_num_ <=2){
            foot_step_joy_support_frame_(i,3) = foot_step_joy_(i,3);
            foot_step_joy_support_frame_(i,4) = foot_step_joy_(i,4);
            foot_step_joy_support_frame_(i,5) = foot_step_joy_(i,5) - foot_step_joy_(current_step_num_-1,5);
        }
        else {
            foot_step_joy_support_frame_(i,3) = foot_step_joy_(i,3);
            foot_step_joy_support_frame_(i,4) = foot_step_joy_(i,4);
            foot_step_joy_support_frame_(i,5) = foot_step_joy_(i,5) - foot_step_joy_(1,5);
        }
      }
    }


    for(int j=0;j<3;j++)
      temp_global_position(j) = supportfoot_float_init_(j);

    temp_local_position = reference.linear().transpose()*(temp_global_position-reference.translation());

    for(int j=0;j<3;j++)
      supportfoot_support_init_(j) = temp_local_position(j);

    supportfoot_support_init_(3) = supportfoot_float_init_(3);
    supportfoot_support_init_(4) = supportfoot_float_init_(4);

    if(current_step_num_ == 0)
      supportfoot_support_init_(5) = 0;
    else{
        if(current_step_num_<=2){
            supportfoot_support_init_(5) = supportfoot_float_init_(5) - foot_step_joy_(current_step_num_-1,5);
        }
        else {
            supportfoot_support_init_(5) = supportfoot_float_init_(5) - foot_step_joy_(1,5);
        }
    }

}
void WalkingController::JoyaddZmpOffset()
{
  lfoot_zmp_offset_ = -0.04;
  rfoot_zmp_offset_ = 0.04;

  double step_planning_num =5;


  foot_step_joy_support_frame_offset_ = foot_step_joy_support_frame_;

  if(foot_step_joy_(0,6) == 0) //right support foot
  {
    //  supportfoot_support_init_offset_(0) = supportfoot_support_init_(0)/2;
    supportfoot_support_init_offset_(1) = supportfoot_support_init_(1) + rfoot_zmp_offset_;
    swingfoot_support_init_offset_(1) = swingfoot_support_init_(1) + lfoot_zmp_offset_;
  }
  else //foot_step_joy_support_frame_
  {
    //  supportfoot_support_init_offset_(0) = supportfoot_support_init_(0);
    supportfoot_support_init_offset_(1) = supportfoot_support_init_(1) + lfoot_zmp_offset_;
    swingfoot_support_init_offset_(1) = swingfoot_support_init_(1) + rfoot_zmp_offset_;
  }
  if(joystick_walking_on_ == false){
      double seq = current_step_num_-joystick_stop_begin_num_;

      if(foot_step_joy_(seq,6) == 0) //right support foot
      {
        //  supportfoot_support_init_offset_(0) = supportfoot_support_init_(0)/2;
        supportfoot_support_init_offset_(1) = supportfoot_support_init_(1) + rfoot_zmp_offset_;
        swingfoot_support_init_offset_(1) = swingfoot_support_init_(1) + lfoot_zmp_offset_;
      }
      else //foot_step_joy_support_frame_
      {
        //  supportfoot_support_init_offset_(0) = supportfoot_support_init_(0);
        supportfoot_support_init_offset_(1) = supportfoot_support_init_(1) + lfoot_zmp_offset_;
        swingfoot_support_init_offset_(1) = swingfoot_support_init_(1) + rfoot_zmp_offset_;
      }
  }

  for(int i=0; i<step_planning_num; i++)
  {
    if(foot_step_joy_(i,6) == 0)//right support, left swing
    {
      foot_step_joy_support_frame_offset_(i,1) += lfoot_zmp_offset_;
    }
    else
    {
      foot_step_joy_support_frame_offset_(i,1) += rfoot_zmp_offset_;
    }
  }
}
void WalkingController::JoyonestepZmp(unsigned int tick, Eigen::VectorXd& temp_px, Eigen::VectorXd& temp_py)
{
  temp_px.resize(t_total_);
  temp_py.resize(t_total_);
  temp_px.setZero();
  temp_py.setZero();

  double Kx = 0.0;
  double Kx2 = 0.0;
  double Ky = 0.0;
  double Ky2 = 0.0;

  if(current_step_num_ == 0)
  {
      if(tick ==0){
          Kx = supportfoot_support_init_offset_(0);
          Kx2 = (foot_step_joy_support_frame_(0,0)- supportfoot_support_init_offset_(0))/2.0;

          //    Kx2 = (foot_step_joy_support_frame_(current_step_number,0))/2.0;


          Ky = supportfoot_support_init_offset_(1) - com_support_init_(1);
          Ky2 = (foot_step_joy_support_frame_(0,1)- supportfoot_support_init_offset_(1))/2.0;

          //    Ky2 = (foot_step_joy_support_frame_(current_step_number,1))/2.0;

          for(int i=0; i<t_total_; i++)
          {
            if(i < t_rest_init_)
            {
              temp_px(i) = 0.0;
              temp_py(i) = com_support_init_(1)+com_offset_(1);
            }
            else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
            {
              temp_px(i) = Kx/t_double1_*(i+1-t_rest_init_);
              temp_py(i) = com_support_init_(1)+com_offset_(1) + Ky/t_double1_*(i+1-t_rest_init_);
            }
            else if(i>= t_rest_init_+t_double1_ && i< t_total_-t_rest_last_-t_double2_)
            {
              temp_px(i) = supportfoot_support_init_offset_(0);
              temp_py(i) = supportfoot_support_init_offset_(1);
            }
            else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
            {
              temp_px(i) = supportfoot_support_init_offset_(0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
              temp_py(i) = supportfoot_support_init_offset_(1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
            }
            else
            {
              temp_px(i) = temp_px(i-1);
              temp_py(i) = temp_py(i-1);
            }
          }
      } // end of tick 0
      else if(tick ==1){
          Kx = foot_step_joy_support_frame_offset_(tick-1,0) - (foot_step_joy_support_frame_(tick-1,0) + supportfoot_support_init_(0))/2.0;
          Kx2 = (foot_step_joy_support_frame_(tick,0)+foot_step_joy_support_frame_(tick-1,0))/2.0 - foot_step_joy_support_frame_offset_(tick-1,0);

          Ky =  foot_step_joy_support_frame_offset_(tick-1,1) - (foot_step_joy_support_frame_(tick-1,1) + supportfoot_support_init_(1))/2.0;
          Ky2 = (foot_step_joy_support_frame_(tick,1)+foot_step_joy_support_frame_(tick-1,1))/2.0 - foot_step_joy_support_frame_offset_(tick-1,1);
          for(int i=0; i<t_total_; i++)
          {
            if(i < t_rest_init_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+supportfoot_support_init_(0))/2.0;
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+supportfoot_support_init_(1))/2.0;

            }
            else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+supportfoot_support_init_(0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+supportfoot_support_init_(1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
            }
            else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0);
              temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1);
            }
            else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
              temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
            }
            else
            {
              temp_px(i) = temp_px(i-1);
              temp_py(i) = temp_py(i-1);
            }
          }
      }
      else{// tick is 2
          Kx = foot_step_joy_support_frame_offset_(tick-1,0) - (foot_step_joy_support_frame_(tick-1,0) + foot_step_joy_support_frame_(tick-2,0))/2.0;
          Kx2 = (foot_step_joy_support_frame_(tick,0)+foot_step_joy_support_frame_(tick-1,0))/2.0 - foot_step_joy_support_frame_offset_(tick-1,0);

          Ky =  foot_step_joy_support_frame_offset_(tick-1,1) - (foot_step_joy_support_frame_(tick-1,1) + foot_step_joy_support_frame_(tick-2,1))/2.0;
          Ky2 = (foot_step_joy_support_frame_(tick,1)+foot_step_joy_support_frame_(tick-1,1))/2.0 -  foot_step_joy_support_frame_offset_(tick-1,1);

          for(int i=0; i<t_total_; i++)
          {
            if(i < t_rest_init_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick-2,0))/2.0;
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick-2,1))/2.0;
            }
            else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick-2,0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick-2,1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
            }
            else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0);
              temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1);
            }
            else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
              temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
            }
            else
            {
              temp_px(i) = temp_px(i-1);
              temp_py(i) = temp_py(i-1);
            }
          }
      }

  }
  else if(current_step_num_ ==1){
      if(tick ==0){
          Kx = foot_step_joy_support_frame_offset_(tick,0) - (foot_step_joy_support_frame_(tick,0) + supportfoot_support_init_(0))/2.0;
          Kx2 = (foot_step_joy_support_frame_(tick+1,0)+foot_step_joy_support_frame_(tick,0))/2.0 - foot_step_joy_support_frame_offset_(tick,0);

          Ky =  foot_step_joy_support_frame_offset_(tick,1) - (foot_step_joy_support_frame_(tick,1) + supportfoot_support_init_(1))/2.0;
          Ky2 = (foot_step_joy_support_frame_(tick+1,1)+foot_step_joy_support_frame_(tick,1))/2.0 - foot_step_joy_support_frame_offset_(tick,1);
          for(int i=0; i<t_total_; i++)
          {
            if(i < t_rest_init_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick,0)+supportfoot_support_init_(0))/2.0;
              temp_py(i) = (foot_step_joy_support_frame_(tick,1)+supportfoot_support_init_(1))/2.0;

            }
            else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick,0)+supportfoot_support_init_(0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
              temp_py(i) = (foot_step_joy_support_frame_(tick,1)+supportfoot_support_init_(1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
            }
            else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick,0);
              temp_py(i) = foot_step_joy_support_frame_offset_(tick,1);
            }
            else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
              temp_py(i) = foot_step_joy_support_frame_offset_(tick,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
            }
            else
            {
              temp_px(i) = temp_px(i-1);
              temp_py(i) = temp_py(i-1);
            }
          }
      }
      else if(tick ==1){
          Kx = foot_step_joy_support_frame_offset_(tick,0) - (foot_step_joy_support_frame_(tick-1,0) + foot_step_joy_support_frame_(tick,0))/2.0;
          Kx2 = (foot_step_joy_support_frame_(tick,0)+foot_step_joy_support_frame_(tick+1,0))/2.0 - foot_step_joy_support_frame_offset_(tick,0);

          Ky =  foot_step_joy_support_frame_offset_(tick,1) - (foot_step_joy_support_frame_(tick-1,1) + foot_step_joy_support_frame_(tick,1))/2.0;
          Ky2 = (foot_step_joy_support_frame_(tick,1)+foot_step_joy_support_frame_(tick+1,1))/2.0 -  foot_step_joy_support_frame_offset_(tick,1);

          for(int i=0; i<t_total_; i++)
          {
            if(i < t_rest_init_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick,0))/2.0;
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick,1))/2.0;
            }
            else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick,0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick,1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
            }
            else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick,0);
              temp_py(i) = foot_step_joy_support_frame_offset_(tick,1);
            }
            else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
              temp_py(i) = foot_step_joy_support_frame_offset_(tick,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
            }
            else
            {
              temp_px(i) = temp_px(i-1);
              temp_py(i) = temp_py(i-1);
            }
          }
      }
      else { // tick is 2
          Kx = foot_step_joy_support_frame_offset_(tick,0) - (foot_step_joy_support_frame_(tick-1,0) + foot_step_joy_support_frame_(tick,0))/2.0;
          Kx2 = (foot_step_joy_support_frame_(tick,0)+foot_step_joy_support_frame_(tick+1,0))/2.0 - foot_step_joy_support_frame_offset_(tick,0);

          Ky =  foot_step_joy_support_frame_offset_(tick,1) - (foot_step_joy_support_frame_(tick-1,1) + foot_step_joy_support_frame_(tick,1))/2.0;
          Ky2 = (foot_step_joy_support_frame_(tick,1)+foot_step_joy_support_frame_(tick+1,1))/2.0 -  foot_step_joy_support_frame_offset_(tick,1);

          for(int i=0; i<t_total_; i++)
          {
            if(i < t_rest_init_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick,0))/2.0;
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick,1))/2.0;
            }
            else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
            {
              temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick,0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
              temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick,1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
            }
            else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick,0);
              temp_py(i) = foot_step_joy_support_frame_offset_(tick,1);
            }
            else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
            {
              temp_px(i) = foot_step_joy_support_frame_offset_(tick,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
              temp_py(i) = foot_step_joy_support_frame_offset_(tick,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
            }
            else
            {
              temp_px(i) = temp_px(i-1);
              temp_py(i) = temp_py(i-1);
            }
          }
      }
  }
  else{ // current step num >= 2
      Kx = foot_step_joy_support_frame_offset_(tick+1,0) - (foot_step_joy_support_frame_(tick+1,0) + foot_step_joy_support_frame_(tick,0))/2.0;
      Kx2 = (foot_step_joy_support_frame_(tick+2,0)+foot_step_joy_support_frame_(tick+1,0))/2.0 - foot_step_joy_support_frame_offset_(tick+1,0);

      Ky =  foot_step_joy_support_frame_offset_(tick+1,1) - (foot_step_joy_support_frame_(tick+1,1) + foot_step_joy_support_frame_(tick,1))/2.0;
      Ky2 = (foot_step_joy_support_frame_(tick+2,1)+foot_step_joy_support_frame_(tick+1,1))/2.0 -  foot_step_joy_support_frame_offset_(tick+1,1);

      for(int i=0; i<t_total_; i++)
      {
        if(i < t_rest_init_)
        {
          temp_px(i) = (foot_step_joy_support_frame_(tick+1,0)+foot_step_joy_support_frame_(tick,0))/2.0;
          temp_py(i) = (foot_step_joy_support_frame_(tick+1,1)+foot_step_joy_support_frame_(tick,1))/2.0;
        }
        else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
        {
          temp_px(i) = (foot_step_joy_support_frame_(tick+1,0)+foot_step_joy_support_frame_(tick,0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
          temp_py(i) = (foot_step_joy_support_frame_(tick+1,1)+foot_step_joy_support_frame_(tick,1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
        }
        else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
        {
          temp_px(i) = foot_step_joy_support_frame_offset_(tick+1,0);
          temp_py(i) = foot_step_joy_support_frame_offset_(tick+1,1);
        }
        else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
        {
          temp_px(i) = foot_step_joy_support_frame_offset_(tick+1,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
          temp_py(i) = foot_step_joy_support_frame_offset_(tick+1,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
        }
        else
        {
          temp_px(i) = temp_px(i-1);
          temp_py(i) = temp_py(i-1);
        }
      }
  }
//  else if(tick == 1)
//  {
//    Kx = foot_step_joy_support_frame_offset_(tick-1,0) - (foot_step_joy_support_frame_(tick-1,0) + supportfoot_support_init_(0))/2.0;
//    Kx2 = (foot_step_joy_support_frame_(tick,0)+foot_step_joy_support_frame_(tick-1,0))/2.0 - foot_step_joy_support_frame_offset_(tick-1,0);

//    Ky =  foot_step_joy_support_frame_offset_(tick-1,1) - (foot_step_joy_support_frame_(tick-1,1) + supportfoot_support_init_(1))/2.0;
//    Ky2 = (foot_step_joy_support_frame_(tick,1)+foot_step_joy_support_frame_(tick-1,1))/2.0 - foot_step_joy_support_frame_offset_(tick-1,1);
//    for(int i=0; i<t_total_; i++)
//    {
//      if(i < t_rest_init_)
//      {
//        temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+supportfoot_support_init_(0))/2.0;
//        temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+supportfoot_support_init_(1))/2.0;

//      }
//      else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
//      {
//        temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+supportfoot_support_init_(0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
//        temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+supportfoot_support_init_(1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
//      }
//      else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
//      {
//        temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0);
//        temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1);
//      }
//      else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
//      {
//        temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
//        temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
//      }
//      else
//      {
//        temp_px(i) = temp_px(i-1);
//        temp_py(i) = temp_py(i-1);
//      }
//    }
//  }
//  else
//  {
//    Kx = foot_step_joy_support_frame_offset_(tick-1,0) - (foot_step_joy_support_frame_(tick-1,0) + foot_step_joy_support_frame_(tick-2,0))/2.0;
//    Kx2 = (foot_step_joy_support_frame_(tick,0)+foot_step_joy_support_frame_(tick-1,0))/2.0 - foot_step_joy_support_frame_offset_(tick-1,0);

//    Ky =  foot_step_joy_support_frame_offset_(tick-1,1) - (foot_step_joy_support_frame_(tick-1,1) + foot_step_joy_support_frame_(tick-2,1))/2.0;
//    Ky2 = (foot_step_joy_support_frame_(tick,1)+foot_step_joy_support_frame_(tick-1,1))/2.0 -  foot_step_joy_support_frame_offset_(tick-1,1);

//    for(int i=0; i<t_total_; i++)
//    {
//      if(i < t_rest_init_)
//      {
//        temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick-2,0))/2.0;
//        temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick-2,1))/2.0;
//      }
//      else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
//      {
//        temp_px(i) = (foot_step_joy_support_frame_(tick-1,0)+foot_step_joy_support_frame_(tick-2,0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
//        temp_py(i) = (foot_step_joy_support_frame_(tick-1,1)+foot_step_joy_support_frame_(tick-2,1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
//      }
//      else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
//      {
//        temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0);
//        temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1);
//      }
//      else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
//      {
//        temp_px(i) = foot_step_joy_support_frame_offset_(tick-1,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
//        temp_py(i) = foot_step_joy_support_frame_offset_(tick-1,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
//      }
//      else
//      {
//        temp_px(i) = temp_px(i-1);
//        temp_py(i) = temp_py(i-1);
//      }
//    }
//  }
}
void WalkingController::JoystopstepZmp(unsigned int step_number, Eigen::VectorXd& temp_px, Eigen::VectorXd& temp_py)
{
  temp_px.resize(t_total_);
  temp_py.resize(t_total_);
  temp_px.setZero();
  temp_py.setZero();

  double Kx = 0.0;
  double Kx2 = 0.0;
  double Ky = 0.0;
  double Ky2 = 0.0;

 int tick = step_number - joystick_stop_begin_num_;


      Kx = foot_step_joy_support_frame_offset_(tick+1,0) - (foot_step_joy_support_frame_(tick+1,0) + foot_step_joy_support_frame_(tick,0))/2.0;
      Kx2 = (foot_step_joy_support_frame_(tick+2,0)+foot_step_joy_support_frame_(tick+1,0))/2.0 - foot_step_joy_support_frame_offset_(tick+1,0);

      Ky =  foot_step_joy_support_frame_offset_(tick+1,1) - (foot_step_joy_support_frame_(tick+1,1) + foot_step_joy_support_frame_(tick,1))/2.0;
      Ky2 = (foot_step_joy_support_frame_(tick+2,1)+foot_step_joy_support_frame_(tick+1,1))/2.0 -  foot_step_joy_support_frame_offset_(tick+1,1);

      for(int i=0; i<t_total_; i++)
      {
        if(i < t_rest_init_)
        {
          temp_px(i) = (foot_step_joy_support_frame_(tick+1,0)+foot_step_joy_support_frame_(tick,0))/2.0;
          temp_py(i) = (foot_step_joy_support_frame_(tick+1,1)+foot_step_joy_support_frame_(tick,1))/2.0;
        }
        else if(i >= t_rest_init_ && i < t_rest_init_+t_double1_)
        {
          temp_px(i) = (foot_step_joy_support_frame_(tick+1,0)+foot_step_joy_support_frame_(tick,0))/2.0 + Kx/t_double1_*(i+1-t_rest_init_);
          temp_py(i) = (foot_step_joy_support_frame_(tick+1,1)+foot_step_joy_support_frame_(tick,1))/2.0 + Ky/t_double1_*(i+1-t_rest_init_);
        }
        else if(i>= t_rest_init_+t_double1_ & i< t_total_-t_rest_last_-t_double2_)
        {
          temp_px(i) = foot_step_joy_support_frame_offset_(tick+1,0);
          temp_py(i) = foot_step_joy_support_frame_offset_(tick+1,1);
        }
        else if(i >= t_total_-t_rest_last_-t_double2_ && i< t_total_-t_rest_last_)
        {
          temp_px(i) = foot_step_joy_support_frame_offset_(tick+1,0) + Kx2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
          temp_py(i) = foot_step_joy_support_frame_offset_(tick+1,1) + Ky2/(t_double2_)*(i+1-(t_total_-t_double2_-t_rest_last_));
        }
        else
        {
          temp_px(i) = temp_px(i-1);
          temp_py(i) = temp_py(i-1);
        }
      }
}
void WalkingController::JoyFootTrajectory()
{
    if(walking_tick_ == 0)
        cout<<"foot trajectory for joystick walking"<<endl;

  Eigen::Vector6d target_swing_foot;

  bool left_foot_support;
  bool right_foot_support;

  if(joystick_walking_flag_==true){
      if(current_step_num_<=2){
          for(int i=0; i<6; i++)
            target_swing_foot(i) = foot_step_joy_support_frame_(current_step_num_,i);

          if(foot_step_joy_(current_step_num_,6) ==1){
              left_foot_support = true;
              right_foot_support = false;
          }
          else {
              left_foot_support = false;
              right_foot_support = true;
          }
      }
      else {
          if(joystick_walking_on_ == true){
              for(int i=0; i<6; i++)
                target_swing_foot(i) = foot_step_joy_support_frame_(2,i);

              if(foot_step_joy_(2,6) ==1){
                  left_foot_support = true;
                  right_foot_support = false;
              }
              else {
                  left_foot_support = false;
                  right_foot_support = true;
              }
          }
          else {
              double tick;
              tick = current_step_num_ - joystick_stop_begin_num_;
              for(int i=0;i<6;i++)
                  target_swing_foot(i) = foot_step_joy_support_frame_(2+tick,i);

              if(foot_step_joy_(2+tick,6) ==1){
                  left_foot_support = true;
                  right_foot_support = false;
              }
              else {
                  left_foot_support = false;
                  right_foot_support = true;
              }

              if(walking_tick_ == t_start_)
                  cout<<"swing target at stop sequence: "<<endl<<target_swing_foot<<endl;

          }

      }

  }

  if(walking_tick_ < t_start_real_+t_double1_)
  {
    lfoot_trajectory_support_.translation() = lfoot_support_init_.translation();
    lfoot_trajectory_dot_support_.setZero();


    if(left_foot_support) //left foot support
      lfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_,t_start_real_,lfoot_support_init_.translation()(2),0.0,0.0,0.0);
    else // swing foot (right foot support)
    {
      if(current_step_num_ == 0)
        lfoot_trajectory_support_.translation()(2) = lfoot_support_init_.translation()(2);
      else
      {
        if(walking_tick_ < t_start_)
          lfoot_trajectory_support_.translation()(2) = lfoot_support_init_.translation()(2);
        else if(walking_tick_ >= t_start_ && walking_tick_ < t_start_real_)
          lfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_,t_start_real_,lfoot_support_init_.translation()(2),0.0,0.0,0.0);
        else
          lfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_real_,t_start_real_+t_double1_,0.0,0.0,0.0,0.0);
      }
    }


    lfoot_trajectory_euler_support_ = lfoot_support_euler_init_;

    for(int i=0; i<2; i++)
      lfoot_trajectory_euler_support_(i) = DyrosMath::cubic(walking_tick_,t_start_,t_start_real_,lfoot_support_euler_init_(i),0.0,0.0,0.0);

    lfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(lfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(lfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(lfoot_trajectory_euler_support_(0));


    rfoot_trajectory_support_.translation() = rfoot_support_init_.translation();
    rfoot_trajectory_dot_support_.setZero();
    //rfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_,_T_Start_real,rfoot_trajectory_init_.translation()(2),0.0,0.0,0.0);


    if(right_foot_support) //right foot support
      rfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_,t_start_real_,rfoot_support_init_.translation()(2),0.0,0.0,0.0);
    else // swing foot (left foot support)
    {
      if(current_step_num_ == 0)
        rfoot_trajectory_support_.translation()(2) = rfoot_support_init_.translation()(2);
      else
      {
        if(walking_tick_ < t_start_)
          rfoot_trajectory_support_.translation()(2) = rfoot_support_init_.translation()(2);
        else if(walking_tick_ >= t_start_ && walking_tick_ < t_start_real_)
          rfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_,t_start_real_,rfoot_support_init_.translation()(2),0.0,0.0,0.0);
        else
          rfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_real_,t_start_real_+t_double1_,0.0,0.0,0.0,0.0);
      }
    }


    rfoot_trajectory_euler_support_ = rfoot_support_euler_init_;

    for(int i=0; i<2; i++)
      rfoot_trajectory_euler_support_(i) = DyrosMath::cubic(walking_tick_,t_start_,t_start_real_,rfoot_support_euler_init_(i),0.0,0.0,0.0);

    rfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(rfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(rfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(rfoot_trajectory_euler_support_(0));

  }
  else if(walking_tick_ >= t_start_real_+t_double1_ && walking_tick_ < t_start_+t_total_-t_double2_-t_rest_last_)
  {
    double t_rest_temp = 0.05*hz_;
    double ankle_temp;
    ankle_temp = 0*DEG2RAD;

    if(left_foot_support) //Left foot support : Left foot is fixed at initial values, and Right foot is set to go target position
    {
      lfoot_trajectory_support_.translation() = lfoot_support_init_.translation();
      lfoot_trajectory_euler_support_ = lfoot_support_euler_init_;
      lfoot_trajectory_euler_support_.setZero();

      lfoot_trajectory_dot_support_.setZero();
      lfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(lfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(lfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(lfoot_trajectory_euler_support_(0));

      // setting for Left supporting foot

      if(walking_tick_ < t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0) // the period for lifting the right foot
      {
        rfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0,foot_height_,0.0,0.0);
        rfoot_trajectory_dot_support_(2) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0,foot_height_,0.0,0.0,hz_);

        rfoot_trajectory_euler_support_(1) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0.0,ankle_temp,0.0,0.0);
        rfoot_trajectory_dot_support_(4) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0.0,ankle_temp,0.0,0.0,hz_);
      } // the period for lifting the right foot
      else
      {
        rfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-t_rest_temp,foot_height_,target_swing_foot(2),0.0,0.0);
        rfoot_trajectory_dot_support_(2) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-t_rest_temp,foot_height_,target_swing_foot(2),0.0,0.0,hz_);

        rfoot_trajectory_euler_support_(1) = DyrosMath::cubic(walking_tick_,t_start_+t_total_-t_rest_last_-t_double2_-t_rest_temp,t_start_+t_total_-t_rest_last_,ankle_temp,0.0,0.0,0.0);
        rfoot_trajectory_dot_support_(4) = DyrosMath::cubicDot(walking_tick_,t_start_+t_total_-t_rest_last_-t_double2_-t_rest_temp,t_start_+t_total_-t_rest_last_,ankle_temp,0.0,0.0,0.0,hz_);
      } // the period for putting the right foot

      rfoot_trajectory_euler_support_(0) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,0.0,target_swing_foot(0+3),0.0,0.0);
      rfoot_trajectory_dot_support_(0+3) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,0.0,target_swing_foot(0+3),0.0,0.0,hz_);

      for(int i=0; i<2; i++)
      {
        rfoot_trajectory_support_.translation()(i) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+2*t_rest_temp,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-2*t_rest_temp,rfoot_support_init_.translation()(i),target_swing_foot(i),0.0,0.0);
        rfoot_trajectory_dot_support_(i) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+2*t_rest_temp,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-2*t_rest_temp,rfoot_support_init_.translation()(i),target_swing_foot(i),0.0,0.0,hz_);
      }

      rfoot_trajectory_euler_support_(2) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,rfoot_support_euler_init_(2),target_swing_foot(5),0.0,0.0);
      rfoot_trajectory_dot_support_(5) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,rfoot_support_euler_init_(2),target_swing_foot(5),0.0,0.0,hz_);

      rfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(rfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(rfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(rfoot_trajectory_euler_support_(0));
    }
    else if(right_foot_support) // Right foot support : Right foot is fixed at initial values, and Left foot is set to go target position
    {
      rfoot_trajectory_support_.translation() = rfoot_support_init_.translation();
      rfoot_trajectory_support_.translation()(2) = 0.0;
      //rfoot_trajectory_support_.linear() = rfoot_trajectory_init_.linear();
      rfoot_trajectory_euler_support_ = rfoot_support_euler_init_;
      rfoot_trajectory_euler_support_(0) = 0.0;
      rfoot_trajectory_euler_support_(1) = 0.0;
      rfoot_trajectory_dot_support_.setZero();

      double ankle_temp;
      ankle_temp = 0*DEG2RAD;
      //ankle_temp = -15*DEG2RAD;

      rfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(rfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(rfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(rfoot_trajectory_euler_support_(0));

      if(walking_tick_ < t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0)
      {

        lfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0,foot_height_,0.0,0.0);
        lfoot_trajectory_dot_support_(2) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0,foot_height_,0.0,0.0,hz_);

        lfoot_trajectory_euler_support_(1) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0.0,ankle_temp,0.0,0.0);
        lfoot_trajectory_dot_support_(4) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+t_rest_temp,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,0.0,ankle_temp,0.0,0.0,hz_);

      }
      else
      {
        lfoot_trajectory_euler_support_(1) = DyrosMath::cubic(walking_tick_,t_start_+t_total_-t_rest_last_-t_double2_-t_rest_temp,t_start_+t_total_-t_rest_last_,ankle_temp,0.0,0.0,0.0);
        lfoot_trajectory_dot_support_(4) = DyrosMath::cubicDot(walking_tick_,t_start_+t_total_-t_rest_last_-t_double2_-t_rest_temp,t_start_+t_total_-t_rest_last_,ankle_temp,0.0,0.0,0.0,hz_);


        lfoot_trajectory_support_.translation()(2) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-t_rest_temp,foot_height_,target_swing_foot(2),0.0,0.0);
        lfoot_trajectory_dot_support_(2) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+(t_total_-t_rest_init_-t_rest_last_-t_double1_-t_double2_-t_imp_)/2.0,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-t_rest_temp,foot_height_,target_swing_foot(2),0.0,0.0,hz_);
      }

      lfoot_trajectory_euler_support_(0) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,0.0,target_swing_foot(0+3),0.0,0.0);
      lfoot_trajectory_dot_support_(0+3) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,0.0,target_swing_foot(0+3),0.0,0.0,hz_);

      for(int i=0; i<2; i++)
      {
        lfoot_trajectory_support_.translation()(i) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_+2*t_rest_temp,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-2*t_rest_temp,lfoot_support_init_.translation()(i),target_swing_foot(i),0.0,0.0);
        lfoot_trajectory_dot_support_(i) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_+2*t_rest_temp,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_-2*t_rest_temp,lfoot_support_init_.translation()(i),target_swing_foot(i),0.0,0.0,hz_);
      }

      //  for(int i=0; i<3; i++)
      //  {
      //      lfoot_trajectory_euler_support_(i) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_,_T_Start+t_total_-t_rest_last_-t_double2_-t_imp_,0.0,0.0,target_swing_foot(i+3),0.0);
      //      lfoot_trajectory_dot_support_(i+3) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_,_T_Start+t_total_-t_rest_last_-t_double2_-t_imp_,0.0,0.0,target_swing_foot(i+3),0.0,hz_);
      //  }


      lfoot_trajectory_euler_support_(2) = DyrosMath::cubic(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,lfoot_support_euler_init_(2),target_swing_foot(5),0.0,0.0);
      lfoot_trajectory_dot_support_(5) = DyrosMath::cubicDot(walking_tick_,t_start_real_+t_double1_,t_start_+t_total_-t_rest_last_-t_double2_-t_imp_,lfoot_support_euler_init_(2),target_swing_foot(5),0.0,0.0,hz_);

      lfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(lfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(lfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(lfoot_trajectory_euler_support_(0));
    }
    else
    {
      lfoot_trajectory_support_.translation() = lfoot_support_init_.translation();
      lfoot_trajectory_support_.linear() = lfoot_support_init_.linear();
      lfoot_trajectory_euler_support_ = lfoot_support_euler_init_;
      lfoot_trajectory_dot_support_.setZero();

      rfoot_trajectory_support_.translation() = rfoot_support_init_.translation();
      rfoot_trajectory_support_.linear() = rfoot_support_init_.linear();
      rfoot_trajectory_euler_support_ = rfoot_support_euler_init_;
      rfoot_trajectory_dot_support_.setZero();
    }
  }
  else
  {
    if(left_foot_support)
    {
      lfoot_trajectory_support_.translation() = lfoot_support_init_.translation();
      lfoot_trajectory_support_.translation()(2) = 0.0;
      lfoot_trajectory_euler_support_ = lfoot_support_euler_init_;
      lfoot_trajectory_euler_support_(0) = 0.0;
      lfoot_trajectory_euler_support_(1) = 0.0;
      lfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(lfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(lfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(lfoot_trajectory_euler_support_(0));
      lfoot_trajectory_dot_support_.setZero();

      for(int i=0; i<3; i++)
      {
        rfoot_trajectory_support_.translation()(i) = target_swing_foot(i);
        rfoot_trajectory_euler_support_(i) = target_swing_foot(i+3);
      }
      rfoot_trajectory_dot_support_.setZero();

      rfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(rfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(rfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(rfoot_trajectory_euler_support_(0));
    }
    else if (right_foot_support)
    {
      rfoot_trajectory_support_.translation() = rfoot_support_init_.translation();
      rfoot_trajectory_support_.translation()(2) = 0.0;
      //rfoot_trajectory_support_.linear() = rfoot_trajectory_init_.linear();
      rfoot_trajectory_euler_support_ = rfoot_support_euler_init_;
      rfoot_trajectory_euler_support_(0) = 0.0;
      rfoot_trajectory_euler_support_(1) = 0.0;
      rfoot_trajectory_dot_support_.setZero();

      rfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(rfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(rfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(rfoot_trajectory_euler_support_(0));


      for(int i=0; i<3; i++)
      {
        lfoot_trajectory_support_.translation()(i) = target_swing_foot(i);
        lfoot_trajectory_euler_support_(i) = target_swing_foot(i+3);
      }
      lfoot_trajectory_dot_support_.setZero();
      lfoot_trajectory_support_.linear() = DyrosMath::rotateWithZ(lfoot_trajectory_euler_support_(2))*DyrosMath::rotateWithY(lfoot_trajectory_euler_support_(1))*DyrosMath::rotateWithX(lfoot_trajectory_euler_support_(0));
    }
    else
    {
      lfoot_trajectory_support_.translation() = lfoot_support_init_.translation();
      lfoot_trajectory_support_.linear() = lfoot_support_init_.linear();
      lfoot_trajectory_euler_support_ = lfoot_support_euler_init_;
      lfoot_trajectory_dot_support_.setZero();

      rfoot_trajectory_support_.translation() = rfoot_support_init_.translation();
      rfoot_trajectory_support_.linear() = rfoot_support_init_.linear();
      rfoot_trajectory_euler_support_ = rfoot_support_euler_init_;
      rfoot_trajectory_dot_support_.setZero();
    }
  }
}
}
