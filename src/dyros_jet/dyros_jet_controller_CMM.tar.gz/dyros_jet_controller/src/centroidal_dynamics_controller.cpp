#include "dyros_jet_controller/dyros_jet_model.h"
#include "dyros_jet_controller/walking_controller_hw.h"
#include "cvxgen_6_8_0/cvxgen/solver.h"
#include <chrono>
#include <stdio.h>

namespace dyros_jet_controller
{
 void WalkingController::UpdateCentroidalMomentumMatrix(){
        Eigen::Matrix<double, DyrosJetModel::MODEL_WITH_VIRTUAL_DOF, 1> q_temp, qdot_temp;
        q_temp.setZero();
        qdot_temp.setZero();

        q_temp.segment<12>(6) = desired_q_not_compensated_.segment<12>(0);
        if(walking_tick_ == 0)
            q_temp.segment<28>(6) = current_q_.segment<28>(0);

        Eigen::Matrix<double, 3, 28> LMM_rbdl;
        Eigen::Matrix<double, 3, 28> AMM_rbdl;

        for(int i=0;i<28;i++){
            qdot_temp.setZero();
            qdot_temp(6+i) = 1.0;

            model_.updateKinematics(q_temp,qdot_temp);

            LMM_rbdl.col(i) = model_.getCurrentComLinearMomentum();
            AMM_rbdl.col(i) = model_.getCurrentComAngularMomentum();
        }

        Augmented_Centroidal_Momentum_Matrix_.block<3,28>(0,0) = LMM_rbdl;
        Augmented_Centroidal_Momentum_Matrix_.block<3,28>(3,0) = AMM_rbdl;

 }
 void WalkingController::computeJacobianControl(Eigen::Isometry3d float_lleg_transform, Eigen::Isometry3d float_rleg_transform,
                             Eigen::Vector3d float_lleg_transform_euler, Eigen::Vector3d float_rleg_transform_euler,
                             Eigen::Vector12d& desired_leg_q_dot)
 {
     current_leg_jacobian_l_ = model_.getLegJacobian((DyrosJetModel::EndEffector) 0);
     current_leg_jacobian_r_ = model_.getLegJacobian((DyrosJetModel::EndEffector) 1);

     if(walking_tick_ == 0){
             lfoot_desired_vel_.topRows<3>() = float_lleg_transform.translation() - lfoot_float_current_.translation();
             rfoot_desired_vel_.topRows<3>() = float_rleg_transform.translation() - rfoot_float_current_.translation();
     }
     else {
         lfoot_desired_vel_.topRows<3>() = float_lleg_transform.translation() - pre_lfoot_trajectory_float_.translation();
         rfoot_desired_vel_.topRows<3>() = float_rleg_transform.translation() - pre_rfoot_trajectory_float_.translation();
     }

     Eigen::Vector3d l_leg_phi, r_leg_phi;
     Eigen::Vector6d cubic_xr, cubic_xl;

     for(int i=0;i<3;i++){
         cubic_xl(i) = float_lleg_transform.translation()(i);
         cubic_xl(i+3) = float_lleg_transform_euler(i);

         cubic_xr(i) = float_rleg_transform.translation()(i);
         cubic_xr(i+3) = float_rleg_transform_euler(i);
     }

     if(walking_tick_ == 0 || walking_tick_ == t_start_){
         l_leg_phi = DyrosMath::legGetPhi(lfoot_float_current_, lfoot_float_init_,cubic_xl);
         r_leg_phi = DyrosMath::legGetPhi(rfoot_float_current_, rfoot_float_init_,cubic_xr);
     }
     else{
         l_leg_phi = DyrosMath::legGetPhi(pre_lfoot_trajectory_float_, lfoot_float_init_,cubic_xl);
         r_leg_phi = DyrosMath::legGetPhi(pre_rfoot_trajectory_float_, rfoot_float_init_,cubic_xr);
     }

     lfoot_desired_vel_.bottomRows<3>() = -l_leg_phi;
     rfoot_desired_vel_.bottomRows<3>() = -r_leg_phi;

     lfoot_desired_vel_*=200;
     rfoot_desired_vel_*=200;

 }
}
