#include "dyros_jet_controller/dyros_jet_model.h"
#include "dyros_jet_controller/walking_controller_hw.h"
#include "cvxgen_6_8_0/cvxgen/solver.h"
#include <chrono>
#include <stdio.h>

namespace dyros_jet_controller
{
 void WalkingController::UpdateCentroidalMomentumMatrix(){
        Eigen::Matrix<double, DyrosJetModel::MODEL_WITH_VIRTUAL_DOF, 1> q_temp, qdot_temp;
        q_temp.setZero();
        qdot_temp.setZero();

        q_temp.segment<12>(6) = desired_q_not_compensated_.segment<12>(0);
        if(walking_tick_ == 0)
            q_temp.segment<28>(6) = current_q_.segment<28>(0);

        Eigen::Matrix<double, 3, 28> LMM_rbdl;
        Eigen::Matrix<double, 3, 28> AMM_rbdl;

        for(int i=0;i<28;i++){
            qdot_temp.setZero();
            qdot_temp(6+i) = 1.0;

            model_.updateKinematics(q_temp,qdot_temp);

            LMM_rbdl.col(i) = model_.getCurrentComLinearMomentum();
            AMM_rbdl.col(i) = model_.getCurrentComAngularMomentum();
        }

        Augmented_Centroidal_Momentum_Matrix_.block<3,28>(0,0) = LMM_rbdl;
        Augmented_Centroidal_Momentum_Matrix_.block<3,28>(3,0) = AMM_rbdl;

 }
 void WalkingController::computeJacobianControl(Eigen::Isometry3d float_lleg_transform, Eigen::Isometry3d float_rleg_transform,
                             Eigen::Vector12d& desired_leg_q_dot)
 {

     lfoot_trajectory_euler_float_ = DyrosMath::rot2Euler(lfoot_trajectory_float_.linear());
     rfoot_trajectory_euler_float_ = DyrosMath::rot2Euler(rfoot_trajectory_float_.linear());

        Eigen::Vector6d lp, rp;
        lp.setZero(); rp.setZero();


     if(walking_tick_ == 0 || walking_tick_ == t_start_){
             lfoot_desired_vel_.topRows<3>() = lfoot_trajectory_float_.translation() - lfoot_float_current_.translation();
             rfoot_desired_vel_.topRows<3>() = rfoot_trajectory_float_.translation() - rfoot_float_current_.translation();
//         for(int i=0;i<3;i++){
//             lp(i) = lfoot_trajectory_float_.translation()(i) - lfoot_float_current_.translation()(i);
//             rfoot_desired_vel_(i) = rfoot_trajectory_float_.translation()(i) - rfoot_float_current_.translation()(i);
//         }
     }
     else {
         lfoot_desired_vel_.topRows<3>() = lfoot_trajectory_float_.translation() - pre_lfoot_trajectory_float_.translation();
         rfoot_desired_vel_.topRows<3>() = rfoot_trajectory_float_.translation() - pre_rfoot_trajectory_float_.translation();
//         for(int i=0;i<3;i++){
//             lfoot_desired_vel_(i) = lfoot_trajectory_float_.translation()(i) - pre_lfoot_trajectory_float_.translation()(i);
//             rfoot_desired_vel_(i) = rfoot_trajectory_float_.translation()(i) - pre_rfoot_trajectory_float_.translation()(i);
//         }
     }


     Eigen::Vector3d l_leg_phi, r_leg_phi;
     Eigen::Vector6d cubic_xr, cubic_xl;

     for(int i=0;i<3;i++){
         cubic_xl(i) = lfoot_trajectory_float_.translation()(i);
         cubic_xl(i+3) = lfoot_trajectory_euler_float_(i);

         cubic_xr(i) = rfoot_trajectory_float_.translation()(i);
         cubic_xr(i+3) = rfoot_trajectory_euler_float_(i);
     }

     if(walking_tick_ == 0 || walking_tick_ == t_start_){
         l_leg_phi = DyrosMath::legGetPhi(lfoot_float_current_, lfoot_float_init_,cubic_xl);
         r_leg_phi = DyrosMath::legGetPhi(rfoot_float_current_, rfoot_float_init_,cubic_xr);
     }
     else{
         l_leg_phi = DyrosMath::legGetPhi(pre_lfoot_trajectory_float_, lfoot_float_init_,cubic_xl);
         r_leg_phi = DyrosMath::legGetPhi(pre_rfoot_trajectory_float_, rfoot_float_init_,cubic_xr);
     }


     lfoot_desired_vel_.bottomRows<3>() = -l_leg_phi;
     rfoot_desired_vel_.bottomRows<3>() = -r_leg_phi;


     lfoot_desired_vel_*=200;
     rfoot_desired_vel_*=200;

     current_leg_jacobian_l_ = model_.getLegJacobian((DyrosJetModel::EndEffector) 0);
     current_leg_jacobian_r_ = model_.getLegJacobian((DyrosJetModel::EndEffector) 1);


     //// obtain pseudo-inverse jacobian
     Eigen::Matrix6d jacobian_temp_l, jacobian_temp_r, current_leg_jacobian_l_inv, current_leg_jacobian_r_inv, J_damped, I_Matrix;
     double wl, wr, w0, lambda, a;
     w0 = 0.001;
     lambda = 0.05;
     jacobian_temp_l=current_leg_jacobian_l_*current_leg_jacobian_l_.transpose();
     jacobian_temp_r=current_leg_jacobian_r_*current_leg_jacobian_r_.transpose();
     wr = sqrt(jacobian_temp_r.determinant());
     wl = sqrt(jacobian_temp_l.determinant());


     if (wr<=w0)
     { //Right Jacobi
       a = lambda * pow(1-wr/w0,2);
       J_damped = current_leg_jacobian_r_.transpose()*current_leg_jacobian_r_+a*Eigen::Matrix6d::Identity();
       J_damped = J_damped.inverse();

       cout << "Singularity Region of right leg: " << wr << endl;
       current_leg_jacobian_r_inv = J_damped*current_leg_jacobian_r_.transpose();
     }
     else
     {
       //current_leg_jacobian_r_inv = DyrosMath::pinv(current_leg_jacobian_r_);
       current_leg_jacobian_r_inv = (current_leg_jacobian_r_.transpose()*current_leg_jacobian_r_).inverse()*current_leg_jacobian_r_.transpose();
     }

     if (wl<=w0)
     {
       a = lambda*pow(1-wl/w0,2);
       J_damped = current_leg_jacobian_l_.transpose()*current_leg_jacobian_l_+a*Eigen::Matrix6d::Identity();
       J_damped = J_damped.inverse();

       cout << "Singularity Region of right leg: " << wr << endl;
       current_leg_jacobian_l_inv = J_damped*current_leg_jacobian_l_.transpose();
     }
     else
     {
       current_leg_jacobian_l_inv = (current_leg_jacobian_l_.transpose()*current_leg_jacobian_l_).inverse()*current_leg_jacobian_l_.transpose();
       //current_leg_jacobian_l_inv = DyrosMath::pinv(current_leg_jacobian_r_);
     }


//     Eigen::Vector6d q_lfoot_dot, q_rfoot_dot;

     desired_leg_q_dot.segment<6>(0) = current_leg_jacobian_l_inv*lfoot_desired_vel_;
     desired_leg_q_dot.segment<6>(6) = current_leg_jacobian_r_inv*rfoot_desired_vel_;


     pre_lfoot_trajectory_float_ = lfoot_trajectory_float_;
     pre_rfoot_trajectory_float_ = rfoot_trajectory_float_;

}

 void WalkingController::QPController(VectorQd& optimal_q_dot){


     //// checking for QP controller for IK ///////////
     Eigen::Matrix<double, 12, 12> jacobian_A;
     jacobian_A.setZero();
     jacobian_A.block<6,6>(0,0) = current_leg_jacobian_l_;
     jacobian_A.block<6,6>(6,6) = current_leg_jacobian_r_;

     Eigen::VectorXd y_input(12);
     y_input.segment<6>(0) = lfoot_desired_vel_;
     y_input.segment<6>(6) = rfoot_desired_vel_;

     Eigen::Matrix12d iden;
     iden.setIdentity();


//     // case of considering only leg ///
//     /// \brief A_cmm_leg
//     ///
//     Eigen::Matrix<double, 6, 12> A_cmm_leg;
//     A_cmm_leg = Augmented_Centroidal_Momentum_Matrix_.block<6,12>(0,0);
//     Eigen::Matrix<double, 12, 6> A_cmm_leg_t;
//     A_cmm_leg_t = A_cmm_leg.transpose();

//     Eigen::Matrix12d Q_temp12;
//     Q_temp12 = A_cmm_leg_t*A_cmm_leg;

//     real_t   H[12*12], A[12*12], lbA[12], ubA[12],lb[12],ub[12], g[12];
//     for(int j=0;j<12;j++){
//         for(int i=0;i<12;i++){
////             H[12*i+j] = iden(i,j);
//             H[12*i + j] = Q_temp12(i,j)+iden(i,j);
//             A[12*i+j] = jacobian_A(i,j);
//         }
//         g[j] = 0.0;
//     }

//     for(int i=0;i<12;i++){
//         lbA[i] = y_input(i);
//         ubA[i] = y_input(i);
//         lb[i] = -10;
//         ub[i] = 10;
//     }

//     real_t xOpt[12];
//     QProblem example(12,12);

//     Options options;
//     options.initialStatusBounds = ST_INACTIVE;
//     options.numRefinementSteps = 1;
//     options.enableCholeskyRefactorisation = 1;
////     options.printLevel = PL_NONE;

//     example.setOptions(options);

//     int_t nWSR = 1000;

//     example.init(H,g,A,lb,ub,lbA,ubA,nWSR);
//     example.getPrimalSolution(xOpt);
//     example.hotstart(g,lb,ub,lbA,ubA,nWSR);
//     example.getPrimalSolution(xOpt);

//     cout<<"optimal q  : ";
//     for(int i=0;i<12;i++){
////         desired_q_(i) = xOpt[i]/hz_ + desired_q_not_compensated_(i);
////         desired_q_(i+6) = xOpt[i+6]/hz_ + desired_q_not_compensated_(i+6);
//         optimal_q_dot(i) = xOpt[i];
//         cout<<xOpt[i]<<"\t";
//     }
//     cout<<endl;

//     /////// case of considering only leg
//     ///
//     /////////////
//     ///
     /// // case of leg plus waist yaw

     Eigen::Matrix<double, 1, 13> A_cmm_2;
     Eigen::Matrix<double, 13, 1> A_cmm_2_t;
     A_cmm_2.block<1,12>(0,0) = Augmented_Centroidal_Momentum_Matrix_.block<1,12>(5,0);
     A_cmm_2.block<1,1>(0,12) = Augmented_Centroidal_Momentum_Matrix_.block<1,1>(5,12);

     A_cmm_2_t = A_cmm_2.transpose();

     Eigen::Matrix<double, 13, 13> Q_13;
     Q_13 = A_cmm_2_t*A_cmm_2;

     Eigen::Matrix<double, 12, 13> A_st_13;
     A_st_13.setZero();
     A_st_13.block<12,12>(0,0) = jacobian_A;

     Eigen::Matrix<double, 13, 13>  Iden_13;
     Iden_13.setIdentity();
     real_t H_13[13*13], A_13[12*13], g_13[13], lbA_13[12], ubA_13[12], lb_13[13], ub_13[13];
     for(int j=0;j<13;j++){
         for(int i=0;i<13;i++){
             H_13[13*i+j] = Q_13(i,j) + Iden_13(i,j);
         }
         for(int i=0;i<12;i++)
             A_13[13*i + j] = A_st_13(i,j);

         g_13[j] = 0.0;

         lb_13[j] = -10;
         ub_13[j] = 10;
     }

     for(int i=0;i<12;i++){
         lbA_13[i] = y_input(i);
         ubA_13[i] = y_input(i);

     }
     if(walking_tick_ == 0){
         cout<<" A cmm matrix : "<<endl<<A_cmm_2<<endl;
         cout<<" Q Matrix : "<<endl<<Q_13<<endl;
         cout<<"A constrint matrix : "<<endl<<A_st_13<<endl;
     }

//     real_t qOpt_13[13];
//     QProblem test_13(13,12);

//     Options option;
//     option.initialStatusBounds = ST_INACTIVE;
//     option.numRefinementSteps =1;
//     option.enableCholeskyRefactorisation = 1;
//     option.enableEqualities = BT_TRUE;

//     test_13.setOptions(option);
//     int_t nWSR_13 = 1000;

//     test_13.init(H_13,g_13,A_13,lb_13,ub_13,lbA_13,ubA_13,nWSR_13);
//     test_13.getPrimalSolution(qOpt_13);
//     test_13.hotstart(g_13,lb_13,ub_13,lbA_13,ubA_13,nWSR_13);
//     test_13.getPrimalSolution(qOpt_13);

//     cout<<"optimal q : ";
//     for(int i=0;i<13;i++){
//         cout<<qOpt_13[i]<<"\t";
//         optimal_q_dot(i) = qOpt_13[i];
//     }
//     cout<<endl;

//     ///
////     /// // case of leg plus waist yaw

//     /////////// checking for QP controller for IK ////////////////////

//     // optimal control for Centroidal momentum

//     Eigen::Matrix<double, 6, 18>  A_G_upper;
//     Eigen::Matrix<double, 6, 12>  A_G_leg;
//     Eigen::Matrix<double, 18, 6>  A_G_upper_t;
//     Eigen::Matrix<double, 12, 6>  A_G_leg_t;

//     A_G_upper = Augmented_Centroidal_Momentum_Matrix_.block<6,18>(0,12);
//     A_G_leg = Augmented_Centroidal_Momentum_Matrix_.block<6,12>(0,0);

//     A_G_upper_t = A_G_upper.transpose();
//     A_G_leg_t = A_G_leg.transpose();

//     Eigen::Matrix<double, 18, 18> Q_temp;
//     Eigen::Matrix<double, 18, 12> A_upper_times_A_leg;

//     Q_temp = A_G_upper_t*A_G_upper;
//     A_upper_times_A_leg = A_G_upper_t*A_G_leg;

//     Eigen::Matrix<double, 18, 1> g_temp;
//     g_temp = A_upper_times_A_leg*desired_leg_q_dot_;


     ////////////////// Used Joint DOF//////////////
     ///// upper : waist yaw, left_shoulder_pitch, right_shoulder_pitch
     ///// lower : leg joint 12
     ///    total 15 DOF are used
     ///
     /// /// /// /// /// /// /// /// /// /// /// /// ///

//     Eigen::Matrix<double, 6, 15> A_G_sel;
//     Eigen::Matrix<double, 15, 6> A_G_sel_t;

//     A_G_sel.block<6,12>(0,0) = Augmented_Centroidal_Momentum_Matrix_.block<6,12>(0,0); // for leg joint
//     A_G_sel.block<6,1>(0,12) = Augmented_Centroidal_Momentum_Matrix_.block<6,1>(0,12); // for waist yaw
//     A_G_sel.block<6,1>(0,13) = Augmented_Centroidal_Momentum_Matrix_.block<6,1>(0,14); // for left shoulder pitch
//     A_G_sel.block<6,1>(0,14) = Augmented_Centroidal_Momentum_Matrix_.block<6,1>(0,21); // for right shoulder pitch

//     A_G_sel_t = A_G_sel.transpose();


     Eigen::Matrix<double, 1, 15> A_G_sel;
     Eigen::Matrix<double, 15, 1> A_G_sel_t;

     A_G_sel.block<1,12>(0,0) = Augmented_Centroidal_Momentum_Matrix_.block<1,12>(5,0); // for leg joint
     A_G_sel.block<1,1>(0,12) = Augmented_Centroidal_Momentum_Matrix_.block<1,1>(5,12); // for waist yaw
     A_G_sel.block<1,1>(0,13) = Augmented_Centroidal_Momentum_Matrix_.block<1,1>(5,14); // for left shoulder pitch
     A_G_sel.block<1,1>(0,14) = Augmented_Centroidal_Momentum_Matrix_.block<1,1>(5,21); // for right shoulder pitch

     A_G_sel_t = A_G_sel.transpose();

//     Eigen::Matrix<double, 12, 15> Selection;
//     Eigen::Matrix<double, 15, 12> Selection_t;

//     Selection.setZero();
//     Selection.block<12,12>(0,0).setIdentity();
//     Selection_t  = Selection.transpose();

//     double w = 0.8;

//     Eigen::Matrix<double, 15, 15> Q_15;
//     Q_15 = (1-w)*A_G_sel_t*A_G_sel + w*Selection_t*jacobian_A.transpose()*jacobian_A*Selection;

//     Eigen::Matrix<double, 15, 1> g_15;
//     g_15 = w*Selection_t*jacobian_A.transpose()*y_input;//////////////////////////

//     /////////////////////////////////////////////////////

     Eigen::Matrix<double, 15, 15> Q_temporary;
     Q_temporary = A_G_sel_t*A_G_sel;

     Eigen::Matrix<double, 12, 15> constraint_A;
     constraint_A.setZero();
     constraint_A.block<12,12>(0,0) = jacobian_A;

//     Eigen::Vector12d constraint_input;
//     constraint_input.segment<6>(0) = lfoot_desired_vel_;
//     constraint_input.segment<6>(6) = rfoot_desired_vel_;

     real_t H_input[15*15], A_input[12*15], lbA_input[12], ubA_input[12], lb_input[15],ub_input[15], g_input[15];

     Eigen::Matrix<double, 15, 15> Iden_15;
     Iden_15.setIdentity();

     for(int j=0;j<15;j++){
         for(int i=0;i<15;i++){
             H_input[15*i + j] = Q_temporary(i,j) + Iden_15(i,j);
         }
         g_input[j] = 0.0;
         lb_input[j] = -10;
         ub_input[j] = 10;
     }

     for(int j=0;j<15;j++){
         for(int i=0;i<12;i++){
             A_input[15*i + j] = constraint_A(i,j);
         }
     }

     for(int i=0;i<12;i++){
         lbA_input[i] = y_input(i);
         ubA_input[i] = y_input(i);
     }
////     cout<<"constriaint input "<<endl<<constraint_input<<endl;

     real_t qOpt[15];
     QProblem test(15,12);

     Options options1;
     options1.initialStatusBounds = ST_INACTIVE;
     options1.numRefinementSteps = 1;
     options1.enableCholeskyRefactorisation = 1;
//     options1.printLevel = PL_NONE;

     test.setOptions(options1);

     int_t nWSR1= 1000;

     test.init(H_input,g_input,A_input,lb_input,ub_input,lbA_input,ubA_input,nWSR1);
     test.getPrimalSolution(qOpt);
     test.hotstart(g_input,lb_input,ub_input,lbA_input,ubA_input,nWSR1);
     test.getPrimalSolution(qOpt);

     optimal_q_dot.setZero();
     for(int i=0;i<12;i++){
         optimal_q_dot(i) = qOpt[i];
     }
     optimal_q_dot(12) = qOpt[12];
     optimal_q_dot(14) = qOpt[13];
     optimal_q_dot(21) = qOpt[14];

     cout<<" q optimal : ";
     for(int i=0;i<15;i++)
         cout<<"\t"<<qOpt[i];
     cout<<endl;

     ////////////// for case leg and waist and upper shoulder pitch //////////
     //// cost function : |A*q_dot|^2 + |Jq_dot-x_dot|^2
     /// unconstrained




}


}
